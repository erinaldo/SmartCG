﻿namespace ModComprobantes
{
    partial class frmCompContRecepcionLotesNuevo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCompContRecepcionLotesNuevo));
            this.radButtonElementPlanCuentas = new Telerik.WinControls.UI.RadButtonElement();
            this.radButtonExit = new Telerik.WinControls.UI.RadButton();
            this.radButtonSave = new Telerik.WinControls.UI.RadButton();
            this.txtDescripcion = new Telerik.WinControls.UI.RadTextBoxControl();
            this.lblDescripcion = new Telerik.WinControls.UI.RadLabel();
            this.lblFormatoAmpliado = new Telerik.WinControls.UI.RadLabel();
            this.lblEstado = new Telerik.WinControls.UI.RadLabel();
            this.lblBiblioteca = new Telerik.WinControls.UI.RadLabel();
            this.txtLote = new Telerik.WinControls.UI.RadTextBoxControl();
            this.lblLote = new Telerik.WinControls.UI.RadLabel();
            this.radTextBoxControlBiblioteca = new Telerik.WinControls.UI.RadTextBoxControl();
            this.radDropDownListEstado = new Telerik.WinControls.UI.RadDropDownList();
            this.radDropDownListFornatoAmpliado = new Telerik.WinControls.UI.RadDropDownList();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescripcion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDescripcion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFormatoAmpliado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEstado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBiblioteca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBoxControlBiblioteca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownListEstado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownListFornatoAmpliado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radButtonElementPlanCuentas
            // 
            this.radButtonElementPlanCuentas.AutoSize = true;
            this.radButtonElementPlanCuentas.DisplayStyle = Telerik.WinControls.DisplayStyle.Image;
            this.radButtonElementPlanCuentas.Image = ((System.Drawing.Image)(resources.GetObject("radButtonElementPlanCuentas.Image")));
            this.radButtonElementPlanCuentas.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.radButtonElementPlanCuentas.Name = "radButtonElementPlanCuentas";
            this.radButtonElementPlanCuentas.Text = "";
            this.radButtonElementPlanCuentas.UseCompatibleTextRendering = false;
            // 
            // radButtonExit
            // 
            this.radButtonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(159)))), ((int)(((byte)(223)))));
            this.radButtonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.radButtonExit.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.radButtonExit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radButtonExit.Location = new System.Drawing.Point(403, 327);
            this.radButtonExit.Name = "radButtonExit";
            this.radButtonExit.Size = new System.Drawing.Size(138, 44);
            this.radButtonExit.TabIndex = 60;
            this.radButtonExit.Text = "Cancelar";
            this.radButtonExit.Click += new System.EventHandler(this.RadButtonExit_Click);
            this.radButtonExit.MouseEnter += new System.EventHandler(this.RadButtonExit_MouseEnter);
            this.radButtonExit.MouseLeave += new System.EventHandler(this.RadButtonExit_MouseLeave);
            ((Telerik.WinControls.UI.RadButtonElement)(this.radButtonExit.GetChildAt(0))).Text = "Cancelar";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButtonExit.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            // 
            // radButtonSave
            // 
            this.radButtonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(159)))), ((int)(((byte)(223)))));
            this.radButtonSave.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.radButtonSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radButtonSave.Location = new System.Drawing.Point(209, 327);
            this.radButtonSave.Name = "radButtonSave";
            this.radButtonSave.Size = new System.Drawing.Size(138, 44);
            this.radButtonSave.TabIndex = 55;
            this.radButtonSave.Text = "Guardar";
            this.radButtonSave.Click += new System.EventHandler(this.RadButtonSave_Click);
            this.radButtonSave.MouseEnter += new System.EventHandler(this.RadButtonSave_MouseEnter);
            this.radButtonSave.MouseLeave += new System.EventHandler(this.RadButtonSave_MouseLeave);
            ((Telerik.WinControls.UI.RadButtonElement)(this.radButtonSave.GetChildAt(0))).Text = "Guardar";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButtonSave.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(47, 217);
            this.txtDescripcion.MaxLength = 30;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Padding = new System.Windows.Forms.Padding(5);
            this.txtDescripcion.Size = new System.Drawing.Size(307, 30);
            this.txtDescripcion.TabIndex = 50;
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.Location = new System.Drawing.Point(47, 194);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(70, 19);
            this.lblDescripcion.TabIndex = 45;
            this.lblDescripcion.Text = "Descripción";
            // 
            // lblFormatoAmpliado
            // 
            this.lblFormatoAmpliado.Location = new System.Drawing.Point(434, 126);
            this.lblFormatoAmpliado.Name = "lblFormatoAmpliado";
            this.lblFormatoAmpliado.Size = new System.Drawing.Size(107, 19);
            this.lblFormatoAmpliado.TabIndex = 35;
            this.lblFormatoAmpliado.Text = "Formato ampliado";
            // 
            // lblEstado
            // 
            this.lblEstado.Location = new System.Drawing.Point(47, 126);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(140, 19);
            this.lblEstado.TabIndex = 25;
            this.lblEstado.Text = "Estado del comprobante";
            // 
            // lblBiblioteca
            // 
            this.lblBiblioteca.Location = new System.Drawing.Point(434, 58);
            this.lblBiblioteca.Name = "lblBiblioteca";
            this.lblBiblioteca.Size = new System.Drawing.Size(60, 19);
            this.lblBiblioteca.TabIndex = 15;
            this.lblBiblioteca.Text = "Biblioteca";
            // 
            // txtLote
            // 
            this.txtLote.Location = new System.Drawing.Point(47, 81);
            this.txtLote.MaxLength = 2;
            this.txtLote.Name = "txtLote";
            this.txtLote.Padding = new System.Windows.Forms.Padding(5);
            this.txtLote.Size = new System.Drawing.Size(40, 30);
            this.txtLote.TabIndex = 10;
            this.txtLote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtCodigo_KeyPress);
            // 
            // lblLote
            // 
            this.lblLote.Location = new System.Drawing.Point(47, 58);
            this.lblLote.Name = "lblLote";
            this.lblLote.Size = new System.Drawing.Size(30, 19);
            this.lblLote.TabIndex = 5;
            this.lblLote.Text = "Lote";
            // 
            // radTextBoxControlBiblioteca
            // 
            this.radTextBoxControlBiblioteca.Enabled = false;
            this.radTextBoxControlBiblioteca.Location = new System.Drawing.Point(434, 81);
            this.radTextBoxControlBiblioteca.MaxLength = 10;
            this.radTextBoxControlBiblioteca.Name = "radTextBoxControlBiblioteca";
            this.radTextBoxControlBiblioteca.Padding = new System.Windows.Forms.Padding(5);
            this.radTextBoxControlBiblioteca.Size = new System.Drawing.Size(161, 30);
            this.radTextBoxControlBiblioteca.TabIndex = 20;
            this.radTextBoxControlBiblioteca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.RadTextBoxControlBiblioteca_KeyPress);
            // 
            // radDropDownListEstado
            // 
            this.radDropDownListEstado.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.radDropDownListEstado.Location = new System.Drawing.Point(47, 149);
            this.radDropDownListEstado.Name = "radDropDownListEstado";
            this.radDropDownListEstado.Padding = new System.Windows.Forms.Padding(2);
            this.radDropDownListEstado.Size = new System.Drawing.Size(170, 25);
            this.radDropDownListEstado.TabIndex = 30;
            // 
            // radDropDownListFornatoAmpliado
            // 
            this.radDropDownListFornatoAmpliado.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.radDropDownListFornatoAmpliado.Location = new System.Drawing.Point(434, 149);
            this.radDropDownListFornatoAmpliado.Name = "radDropDownListFornatoAmpliado";
            this.radDropDownListFornatoAmpliado.Padding = new System.Windows.Forms.Padding(2);
            this.radDropDownListFornatoAmpliado.Size = new System.Drawing.Size(92, 25);
            this.radDropDownListFornatoAmpliado.TabIndex = 40;
            // 
            // frmCompContRecepcionLotesNuevo
            // 
            this.AcceptButton = this.radButtonSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.CancelButton = this.radButtonExit;
            this.ClientSize = new System.Drawing.Size(757, 417);
            this.Controls.Add(this.radDropDownListFornatoAmpliado);
            this.Controls.Add(this.radDropDownListEstado);
            this.Controls.Add(this.radTextBoxControlBiblioteca);
            this.Controls.Add(this.radButtonExit);
            this.Controls.Add(this.radButtonSave);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.lblFormatoAmpliado);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblBiblioteca);
            this.Controls.Add(this.txtLote);
            this.Controls.Add(this.lblLote);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCompContRecepcionLotesNuevo";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Recepción de Lotes - Nuevo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmCompContRecepcionLotesNuevo_FormClosing);
            this.Load += new System.EventHandler(this.FrmCompContRecepcionLotesNuevo_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmCompContRecepcionLotesNuevo_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.radButtonExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescripcion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDescripcion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFormatoAmpliado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEstado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBiblioteca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBoxControlBiblioteca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownListEstado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownListFornatoAmpliado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
        private Telerik.WinControls.UI.RadLabel lblLote;
        private Telerik.WinControls.UI.RadTextBoxControl txtLote;
        private Telerik.WinControls.UI.RadLabel lblBiblioteca;
        private Telerik.WinControls.UI.RadLabel lblEstado;
        private Telerik.WinControls.UI.RadLabel lblFormatoAmpliado;
        private Telerik.WinControls.UI.RadLabel lblDescripcion;
        private Telerik.WinControls.UI.RadTextBoxControl txtDescripcion;
        private Telerik.WinControls.UI.RadButtonElement radButtonElementPlanCuentas;
        private Telerik.WinControls.UI.RadButton radButtonExit;
        private Telerik.WinControls.UI.RadButton radButtonSave;
        private Telerik.WinControls.UI.RadTextBoxControl radTextBoxControlBiblioteca;
        private Telerik.WinControls.UI.RadDropDownList radDropDownListEstado;
        private Telerik.WinControls.UI.RadDropDownList radDropDownListFornatoAmpliado;
    }
}