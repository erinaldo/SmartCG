﻿namespace ModComprobantes
{
    partial class frmCompExtContTransferirFinanComprobantes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radPanelApp = new Telerik.WinControls.UI.RadPanel();
            this.radGroupBoxComprobantes = new Telerik.WinControls.UI.RadGroupBox();
            this.radRadioButtonTodos = new Telerik.WinControls.UI.RadRadioButton();
            this.radRadioButtonTransferidos = new Telerik.WinControls.UI.RadRadioButton();
            this.radRadioButtonNoTransferidos = new Telerik.WinControls.UI.RadRadioButton();
            this.radGridViewComprobantes = new Telerik.WinControls.UI.RadGridView();
            this.gbTransferirComp = new Telerik.WinControls.UI.RadGroupBox();
            this.gbTransferencia = new Telerik.WinControls.UI.RadGroupBox();
            this.chkVerNocomp = new Telerik.WinControls.UI.RadCheckBox();
            this.rbGenerarLoteAdiciona = new Telerik.WinControls.UI.RadRadioButton();
            this.rbGenerarLote = new Telerik.WinControls.UI.RadRadioButton();
            this.gbLote = new Telerik.WinControls.UI.RadGroupBox();
            this.txtDescripcion = new Telerik.WinControls.UI.RadTextBoxControl();
            this.label1 = new Telerik.WinControls.UI.RadLabel();
            this.txtBibliotecaCola = new Telerik.WinControls.UI.RadTextBoxControl();
            this.lblBiliotecaCola = new Telerik.WinControls.UI.RadLabel();
            this.txtCola = new Telerik.WinControls.UI.RadTextBoxControl();
            this.lblCola = new Telerik.WinControls.UI.RadLabel();
            this.txtBibliotecaPrefijo = new Telerik.WinControls.UI.RadTextBoxControl();
            this.lblBibliotecaPrefijo = new Telerik.WinControls.UI.RadLabel();
            this.txtPrefijo = new Telerik.WinControls.UI.RadTextBoxControl();
            this.lblPrefijo = new Telerik.WinControls.UI.RadLabel();
            this.lblNoHayComp = new Telerik.WinControls.UI.RadLabel();
            this.radPanelMenuPath = new Telerik.WinControls.UI.RadPanel();
            this.radLabelTitulo = new Telerik.WinControls.UI.RadLabel();
            this.radPanelAcciones = new Telerik.WinControls.UI.RadPanel();
            this.radButtonTransferir = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.radPanelApp)).BeginInit();
            this.radPanelApp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBoxComprobantes)).BeginInit();
            this.radGroupBoxComprobantes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radRadioButtonTodos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radRadioButtonTransferidos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radRadioButtonNoTransferidos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridViewComprobantes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridViewComprobantes.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbTransferirComp)).BeginInit();
            this.gbTransferirComp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gbTransferencia)).BeginInit();
            this.gbTransferencia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkVerNocomp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbGenerarLoteAdiciona)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbGenerarLote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbLote)).BeginInit();
            this.gbLote.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescripcion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBibliotecaCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBiliotecaCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBibliotecaPrefijo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBibliotecaPrefijo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrefijo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPrefijo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblNoHayComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanelMenuPath)).BeginInit();
            this.radPanelMenuPath.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabelTitulo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanelAcciones)).BeginInit();
            this.radPanelAcciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonTransferir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPanelApp
            // 
            this.radPanelApp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radPanelApp.AutoScroll = true;
            this.radPanelApp.Controls.Add(this.radGroupBoxComprobantes);
            this.radPanelApp.Controls.Add(this.gbTransferirComp);
            this.radPanelApp.Controls.Add(this.lblNoHayComp);
            this.radPanelApp.Location = new System.Drawing.Point(164, 45);
            this.radPanelApp.Name = "radPanelApp";
            this.radPanelApp.Size = new System.Drawing.Size(836, 490);
            this.radPanelApp.TabIndex = 189;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.radPanelApp.GetChildAt(0).GetChildAt(1))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radGroupBoxComprobantes
            // 
            this.radGroupBoxComprobantes.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBoxComprobantes.Controls.Add(this.radRadioButtonTodos);
            this.radGroupBoxComprobantes.Controls.Add(this.radRadioButtonTransferidos);
            this.radGroupBoxComprobantes.Controls.Add(this.radRadioButtonNoTransferidos);
            this.radGroupBoxComprobantes.Controls.Add(this.radGridViewComprobantes);
            this.radGroupBoxComprobantes.HeaderText = "Comprobantes";
            this.radGroupBoxComprobantes.Location = new System.Drawing.Point(19, 16);
            this.radGroupBoxComprobantes.Name = "radGroupBoxComprobantes";
            this.radGroupBoxComprobantes.Size = new System.Drawing.Size(758, 305);
            this.radGroupBoxComprobantes.TabIndex = 195;
            this.radGroupBoxComprobantes.Text = "Comprobantes";
            // 
            // radRadioButtonTodos
            // 
            this.radRadioButtonTodos.CheckState = System.Windows.Forms.CheckState.Checked;
            this.radRadioButtonTodos.Location = new System.Drawing.Point(329, 25);
            this.radRadioButtonTodos.Name = "radRadioButtonTodos";
            this.radRadioButtonTodos.Size = new System.Drawing.Size(57, 19);
            this.radRadioButtonTodos.TabIndex = 2;
            this.radRadioButtonTodos.Text = "Todos";
            this.radRadioButtonTodos.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            this.radRadioButtonTodos.CheckStateChanged += new System.EventHandler(this.RadRadioButtonTodos_CheckStateChanged);
            // 
            // radRadioButtonTransferidos
            // 
            this.radRadioButtonTransferidos.Location = new System.Drawing.Point(182, 25);
            this.radRadioButtonTransferidos.Name = "radRadioButtonTransferidos";
            this.radRadioButtonTransferidos.Size = new System.Drawing.Size(90, 19);
            this.radRadioButtonTransferidos.TabIndex = 1;
            this.radRadioButtonTransferidos.TabStop = false;
            this.radRadioButtonTransferidos.Text = "Transferidos";
            this.radRadioButtonTransferidos.CheckStateChanged += new System.EventHandler(this.RadRadioButtonTransferidos_CheckStateChanged);
            // 
            // radRadioButtonNoTransferidos
            // 
            this.radRadioButtonNoTransferidos.Location = new System.Drawing.Point(29, 25);
            this.radRadioButtonNoTransferidos.Name = "radRadioButtonNoTransferidos";
            this.radRadioButtonNoTransferidos.Size = new System.Drawing.Size(108, 19);
            this.radRadioButtonNoTransferidos.TabIndex = 0;
            this.radRadioButtonNoTransferidos.TabStop = false;
            this.radRadioButtonNoTransferidos.Text = "No transferidos";
            this.radRadioButtonNoTransferidos.CheckStateChanged += new System.EventHandler(this.RadRadioButtonNoTransferidos_CheckStateChanged);
            // 
            // radGridViewComprobantes
            // 
            this.radGridViewComprobantes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radGridViewComprobantes.AutoScroll = true;
            this.radGridViewComprobantes.Location = new System.Drawing.Point(19, 55);
            // 
            // 
            // 
            this.radGridViewComprobantes.MasterTemplate.AllowAddNewRow = false;
            this.radGridViewComprobantes.MasterTemplate.AllowDeleteRow = false;
            this.radGridViewComprobantes.MasterTemplate.AllowEditRow = false;
            this.radGridViewComprobantes.MasterTemplate.AllowSearchRow = true;
            this.radGridViewComprobantes.MasterTemplate.EnableFiltering = true;
            this.radGridViewComprobantes.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.radGridViewComprobantes.Name = "radGridViewComprobantes";
            this.radGridViewComprobantes.Size = new System.Drawing.Size(729, 245);
            this.radGridViewComprobantes.TabIndex = 190;
            this.radGridViewComprobantes.DataBindingComplete += new Telerik.WinControls.UI.GridViewBindingCompleteEventHandler(this.RadGridViewComprobantes_DataBindingComplete);
            // 
            // gbTransferirComp
            // 
            this.gbTransferirComp.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.gbTransferirComp.Controls.Add(this.gbTransferencia);
            this.gbTransferirComp.Controls.Add(this.gbLote);
            this.gbTransferirComp.HeaderText = " Transferir Comprobantes a Finanzas ";
            this.gbTransferirComp.Location = new System.Drawing.Point(19, 327);
            this.gbTransferirComp.Name = "gbTransferirComp";
            this.gbTransferirComp.Size = new System.Drawing.Size(761, 163);
            this.gbTransferirComp.TabIndex = 29;
            this.gbTransferirComp.TabStop = false;
            this.gbTransferirComp.Text = " Transferir Comprobantes a Finanzas ";
            // 
            // gbTransferencia
            // 
            this.gbTransferencia.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.gbTransferencia.Controls.Add(this.chkVerNocomp);
            this.gbTransferencia.Controls.Add(this.rbGenerarLoteAdiciona);
            this.gbTransferencia.Controls.Add(this.rbGenerarLote);
            this.gbTransferencia.HeaderText = " Tipo de Transferencia";
            this.gbTransferencia.Location = new System.Drawing.Point(451, 32);
            this.gbTransferencia.Name = "gbTransferencia";
            this.gbTransferencia.Size = new System.Drawing.Size(308, 128);
            this.gbTransferencia.TabIndex = 95;
            this.gbTransferencia.TabStop = false;
            this.gbTransferencia.Text = " Tipo de Transferencia";
            // 
            // chkVerNocomp
            // 
            this.chkVerNocomp.Location = new System.Drawing.Point(24, 104);
            this.chkVerNocomp.Name = "chkVerNocomp";
            this.chkVerNocomp.Size = new System.Drawing.Size(206, 19);
            this.chkVerNocomp.TabIndex = 115;
            this.chkVerNocomp.Text = "Ver los números de comprobante";
            // 
            // rbGenerarLoteAdiciona
            // 
            this.rbGenerarLoteAdiciona.Location = new System.Drawing.Point(24, 50);
            this.rbGenerarLoteAdiciona.Name = "rbGenerarLoteAdiciona";
            this.rbGenerarLoteAdiciona.Size = new System.Drawing.Size(158, 19);
            this.rbGenerarLoteAdiciona.TabIndex = 105;
            this.rbGenerarLoteAdiciona.Text = "Generar Lote y Adicionar";
            this.rbGenerarLoteAdiciona.CheckStateChanged += new System.EventHandler(this.RbGenerarLoteAdiciona_CheckedChanged);
            // 
            // rbGenerarLote
            // 
            this.rbGenerarLote.Location = new System.Drawing.Point(24, 26);
            this.rbGenerarLote.Name = "rbGenerarLote";
            this.rbGenerarLote.Size = new System.Drawing.Size(121, 19);
            this.rbGenerarLote.TabIndex = 100;
            this.rbGenerarLote.Text = "Solo Generar Lote";
            this.rbGenerarLote.CheckStateChanged += new System.EventHandler(this.RbGenerarLote_CheckedChanged);
            // 
            // gbLote
            // 
            this.gbLote.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.gbLote.Controls.Add(this.txtDescripcion);
            this.gbLote.Controls.Add(this.label1);
            this.gbLote.Controls.Add(this.txtBibliotecaCola);
            this.gbLote.Controls.Add(this.lblBiliotecaCola);
            this.gbLote.Controls.Add(this.txtCola);
            this.gbLote.Controls.Add(this.lblCola);
            this.gbLote.Controls.Add(this.txtBibliotecaPrefijo);
            this.gbLote.Controls.Add(this.lblBibliotecaPrefijo);
            this.gbLote.Controls.Add(this.txtPrefijo);
            this.gbLote.Controls.Add(this.lblPrefijo);
            this.gbLote.HeaderText = " Lote Batch ";
            this.gbLote.Location = new System.Drawing.Point(10, 32);
            this.gbLote.Name = "gbLote";
            this.gbLote.Size = new System.Drawing.Size(366, 128);
            this.gbLote.TabIndex = 65;
            this.gbLote.TabStop = false;
            this.gbLote.Text = " Lote Batch ";
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(88, 20);
            this.txtDescripcion.MaxLength = 36;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Padding = new System.Windows.Forms.Padding(5);
            this.txtDescripcion.Size = new System.Drawing.Size(268, 30);
            this.txtDescripcion.TabIndex = 70;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 19);
            this.label1.TabIndex = 8;
            this.label1.Text = "Descripción";
            // 
            // txtBibliotecaCola
            // 
            this.txtBibliotecaCola.Enabled = false;
            this.txtBibliotecaCola.Location = new System.Drawing.Point(166, 120);
            this.txtBibliotecaCola.MaxLength = 10;
            this.txtBibliotecaCola.Name = "txtBibliotecaCola";
            this.txtBibliotecaCola.Padding = new System.Windows.Forms.Padding(5);
            this.txtBibliotecaCola.Size = new System.Drawing.Size(128, 30);
            this.txtBibliotecaCola.TabIndex = 90;
            this.txtBibliotecaCola.Visible = false;
            // 
            // lblBiliotecaCola
            // 
            this.lblBiliotecaCola.Enabled = false;
            this.lblBiliotecaCola.Location = new System.Drawing.Point(163, 104);
            this.lblBiliotecaCola.Name = "lblBiliotecaCola";
            this.lblBiliotecaCola.Size = new System.Drawing.Size(60, 19);
            this.lblBiliotecaCola.TabIndex = 6;
            this.lblBiliotecaCola.Text = "Biblioteca";
            this.lblBiliotecaCola.Visible = false;
            // 
            // txtCola
            // 
            this.txtCola.Enabled = false;
            this.txtCola.Location = new System.Drawing.Point(22, 120);
            this.txtCola.MaxLength = 10;
            this.txtCola.Name = "txtCola";
            this.txtCola.Padding = new System.Windows.Forms.Padding(5);
            this.txtCola.Size = new System.Drawing.Size(128, 30);
            this.txtCola.TabIndex = 85;
            this.txtCola.Visible = false;
            // 
            // lblCola
            // 
            this.lblCola.Enabled = false;
            this.lblCola.Location = new System.Drawing.Point(19, 104);
            this.lblCola.Name = "lblCola";
            this.lblCola.Size = new System.Drawing.Size(84, 19);
            this.lblCola.TabIndex = 4;
            this.lblCola.Text = "Cola de Salida";
            this.lblCola.Visible = false;
            // 
            // txtBibliotecaPrefijo
            // 
            this.txtBibliotecaPrefijo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBibliotecaPrefijo.Location = new System.Drawing.Point(71, 70);
            this.txtBibliotecaPrefijo.MaxLength = 10;
            this.txtBibliotecaPrefijo.Name = "txtBibliotecaPrefijo";
            this.txtBibliotecaPrefijo.Padding = new System.Windows.Forms.Padding(5);
            this.txtBibliotecaPrefijo.Size = new System.Drawing.Size(128, 30);
            this.txtBibliotecaPrefijo.TabIndex = 80;
            this.txtBibliotecaPrefijo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBibliotecaPrefijo_KeyPress);
            // 
            // lblBibliotecaPrefijo
            // 
            this.lblBibliotecaPrefijo.Location = new System.Drawing.Point(68, 54);
            this.lblBibliotecaPrefijo.Name = "lblBibliotecaPrefijo";
            this.lblBibliotecaPrefijo.Size = new System.Drawing.Size(60, 19);
            this.lblBibliotecaPrefijo.TabIndex = 2;
            this.lblBibliotecaPrefijo.Text = "Biblioteca";
            // 
            // txtPrefijo
            // 
            this.txtPrefijo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrefijo.Location = new System.Drawing.Point(22, 70);
            this.txtPrefijo.MaxLength = 2;
            this.txtPrefijo.Name = "txtPrefijo";
            this.txtPrefijo.Padding = new System.Windows.Forms.Padding(5);
            this.txtPrefijo.Size = new System.Drawing.Size(33, 30);
            this.txtPrefijo.TabIndex = 75;
            this.txtPrefijo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPrefijo_KeyPress);
            // 
            // lblPrefijo
            // 
            this.lblPrefijo.Location = new System.Drawing.Point(19, 54);
            this.lblPrefijo.Name = "lblPrefijo";
            this.lblPrefijo.Size = new System.Drawing.Size(41, 19);
            this.lblPrefijo.TabIndex = 0;
            this.lblPrefijo.Text = "Prefijo";
            // 
            // lblNoHayComp
            // 
            this.lblNoHayComp.Location = new System.Drawing.Point(19, 79);
            this.lblNoHayComp.Name = "lblNoHayComp";
            this.lblNoHayComp.Size = new System.Drawing.Size(142, 19);
            this.lblNoHayComp.TabIndex = 5;
            this.lblNoHayComp.Text = "NoExistenComrpobantes";
            this.lblNoHayComp.Visible = false;
            // 
            // radPanelMenuPath
            // 
            this.radPanelMenuPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radPanelMenuPath.Controls.Add(this.radLabelTitulo);
            this.radPanelMenuPath.Location = new System.Drawing.Point(0, 0);
            this.radPanelMenuPath.Name = "radPanelMenuPath";
            this.radPanelMenuPath.Size = new System.Drawing.Size(960, 45);
            this.radPanelMenuPath.TabIndex = 188;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.radPanelMenuPath.GetChildAt(0).GetChildAt(1))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radLabelTitulo
            // 
            this.radLabelTitulo.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.radLabelTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(159)))), ((int)(((byte)(223)))));
            this.radLabelTitulo.Location = new System.Drawing.Point(13, 15);
            this.radLabelTitulo.Name = "radLabelTitulo";
            this.radLabelTitulo.Size = new System.Drawing.Size(453, 29);
            this.radLabelTitulo.TabIndex = 28;
            this.radLabelTitulo.Text = "Comprobantes extracontables / Transferir a Finanzas";
            // 
            // radPanelAcciones
            // 
            this.radPanelAcciones.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.radPanelAcciones.Controls.Add(this.radButtonTransferir);
            this.radPanelAcciones.Location = new System.Drawing.Point(0, 45);
            this.radPanelAcciones.Name = "radPanelAcciones";
            this.radPanelAcciones.Size = new System.Drawing.Size(163, 1288);
            this.radPanelAcciones.TabIndex = 187;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.radPanelAcciones.GetChildAt(0).GetChildAt(1))).Visibility = Telerik.WinControls.ElementVisibility.Collapsed;
            // 
            // radButtonTransferir
            // 
            this.radButtonTransferir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(159)))), ((int)(((byte)(223)))));
            this.radButtonTransferir.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.radButtonTransferir.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radButtonTransferir.Location = new System.Drawing.Point(13, 16);
            this.radButtonTransferir.Name = "radButtonTransferir";
            this.radButtonTransferir.Size = new System.Drawing.Size(145, 44);
            this.radButtonTransferir.TabIndex = 28;
            this.radButtonTransferir.Text = "Transferir";
            this.radButtonTransferir.Click += new System.EventHandler(this.RadButtonTransferir_Click);
            this.radButtonTransferir.MouseEnter += new System.EventHandler(this.RadButtonTransferir_MouseEnter);
            this.radButtonTransferir.MouseLeave += new System.EventHandler(this.RadButtonTransferir_MouseLeave);
            ((Telerik.WinControls.UI.RadButtonElement)(this.radButtonTransferir.GetChildAt(0))).Text = "Transferir";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButtonTransferir.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            // 
            // frmCompExtContTransferirFinanComprobantes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1394, 819);
            this.Controls.Add(this.radPanelApp);
            this.Controls.Add(this.radPanelMenuPath);
            this.Controls.Add(this.radPanelAcciones);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCompExtContTransferirFinanComprobantes";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Transferir comprobantes extracontables a Finanzas";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmCompExtContTransferirFinanComprobantes_FormClosing);
            this.Load += new System.EventHandler(this.FrmCompExtContTransferirFinanComprobantes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radPanelApp)).EndInit();
            this.radPanelApp.ResumeLayout(false);
            this.radPanelApp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBoxComprobantes)).EndInit();
            this.radGroupBoxComprobantes.ResumeLayout(false);
            this.radGroupBoxComprobantes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radRadioButtonTodos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radRadioButtonTransferidos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radRadioButtonNoTransferidos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridViewComprobantes.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridViewComprobantes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbTransferirComp)).EndInit();
            this.gbTransferirComp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gbTransferencia)).EndInit();
            this.gbTransferencia.ResumeLayout(false);
            this.gbTransferencia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkVerNocomp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbGenerarLoteAdiciona)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbGenerarLote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbLote)).EndInit();
            this.gbLote.ResumeLayout(false);
            this.gbLote.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescripcion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBibliotecaCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBiliotecaCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBibliotecaPrefijo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBibliotecaPrefijo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrefijo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPrefijo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblNoHayComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanelMenuPath)).EndInit();
            this.radPanelMenuPath.ResumeLayout(false);
            this.radPanelMenuPath.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabelTitulo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanelAcciones)).EndInit();
            this.radPanelAcciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButtonTransferir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Telerik.WinControls.UI.RadLabel lblNoHayComp;
        private Telerik.WinControls.UI.RadGroupBox gbTransferirComp;
        private Telerik.WinControls.UI.RadGroupBox gbLote;
        private Telerik.WinControls.UI.RadTextBoxControl txtDescripcion;
        private Telerik.WinControls.UI.RadLabel label1;
        private Telerik.WinControls.UI.RadTextBoxControl txtBibliotecaCola;
        private Telerik.WinControls.UI.RadLabel lblBiliotecaCola;
        private Telerik.WinControls.UI.RadTextBoxControl txtCola;
        private Telerik.WinControls.UI.RadLabel lblCola;
        private Telerik.WinControls.UI.RadTextBoxControl txtBibliotecaPrefijo;
        private Telerik.WinControls.UI.RadLabel lblBibliotecaPrefijo;
        private Telerik.WinControls.UI.RadTextBoxControl txtPrefijo;
        private Telerik.WinControls.UI.RadLabel lblPrefijo;
        private Telerik.WinControls.UI.RadGroupBox gbTransferencia;
        private Telerik.WinControls.UI.RadCheckBox chkVerNocomp;
        private Telerik.WinControls.UI.RadRadioButton rbGenerarLoteAdiciona;
        private Telerik.WinControls.UI.RadRadioButton rbGenerarLote;
        private Telerik.WinControls.UI.RadPanel radPanelAcciones;
        private Telerik.WinControls.UI.RadButton radButtonTransferir;
        private Telerik.WinControls.UI.RadPanel radPanelMenuPath;
        private Telerik.WinControls.UI.RadLabel radLabelTitulo;
        private Telerik.WinControls.UI.RadPanel radPanelApp;
        private Telerik.WinControls.UI.RadGridView radGridViewComprobantes;
        private Telerik.WinControls.UI.RadGroupBox radGroupBoxComprobantes;
        private Telerik.WinControls.UI.RadRadioButton radRadioButtonTodos;
        private Telerik.WinControls.UI.RadRadioButton radRadioButtonTransferidos;
        private Telerik.WinControls.UI.RadRadioButton radRadioButtonNoTransferidos;
    }
}