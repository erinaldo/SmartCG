﻿namespace ModSII
{
    partial class frmSiiConsultaViewFactInformadaProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSiiConsultaViewFactInformadaProveedor));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbCabecera = new System.Windows.Forms.GroupBox();
            this.txtNombreRazonSocialEmisorFact = new System.Windows.Forms.TextBox();
            this.lblNombreRazonSocialEmisorFact = new System.Windows.Forms.Label();
            this.txtEmisorFacturaNIF = new System.Windows.Forms.TextBox();
            this.lblEmisorFacturaNIF = new System.Windows.Forms.Label();
            this.txtFechaHoraEstadoCuadre = new System.Windows.Forms.TextBox();
            this.lblFechaHoraEstadoCuadre = new System.Windows.Forms.Label();
            this.txtProveedorNombreRazonSocial = new System.Windows.Forms.TextBox();
            this.lblProveedorNombreRazonSocial = new System.Windows.Forms.Label();
            this.txtEstadoCuadre = new System.Windows.Forms.TextBox();
            this.lblEstadoCudre = new System.Windows.Forms.Label();
            this.txtFechaDoc = new System.Windows.Forms.TextBox();
            this.lblFechaDoc = new System.Windows.Forms.Label();
            this.txtNoFact = new System.Windows.Forms.TextBox();
            this.lblFechaFactura = new System.Windows.Forms.Label();
            this.txtProveedorNIF = new System.Windows.Forms.TextBox();
            this.lblProveedorNIF = new System.Windows.Forms.Label();
            this.lblPeriodo = new System.Windows.Forms.Label();
            this.txtPeriodo = new System.Windows.Forms.TextBox();
            this.lblEjercicio = new System.Windows.Forms.Label();
            this.txtEjercicio = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonSalir = new System.Windows.Forms.ToolStripButton();
            this.tabControlFactura = new System.Windows.Forms.TabControl();
            this.tabPageDatosGrles = new System.Windows.Forms.TabPage();
            this.txtFacturaSinIdentifDestinatarioArticulo61d = new System.Windows.Forms.TextBox();
            this.lblFacturaSinIdentifDestinatarioArticulo61d = new System.Windows.Forms.Label();
            this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas = new System.Windows.Forms.TextBox();
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas = new System.Windows.Forms.Label();
            this.txtMacrodato = new System.Windows.Forms.TextBox();
            this.lblMacrodato = new System.Windows.Forms.Label();
            this.txtRegistroPrevioGGEEoREDEMEoCompetencia = new System.Windows.Forms.TextBox();
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia = new System.Windows.Forms.Label();
            this.txtFactSimplificadaArticulos72_73 = new System.Windows.Forms.TextBox();
            this.lblFactSimplificadaArticulos72_73 = new System.Windows.Forms.Label();
            this.txtRefExterna = new System.Windows.Forms.TextBox();
            this.lblRefExterna = new System.Windows.Forms.Label();
            this.txtNumRegistroAcuerdoFacturacion = new System.Windows.Forms.TextBox();
            this.lblNumRegistroAcuerdoFacturacion = new System.Windows.Forms.Label();
            this.txtClaveRegimenEspecialOTrasAdicional2 = new System.Windows.Forms.TextBox();
            this.lblClaveRegimenEspecialOTrasAdicional2 = new System.Windows.Forms.Label();
            this.txtClaveRegimenEspecialOTrasAdicional1 = new System.Windows.Forms.TextBox();
            this.lblClaveRegimenEspecialOTrasAdicional1 = new System.Windows.Forms.Label();
            this.txtCupon = new System.Windows.Forms.TextBox();
            this.lblCupon = new System.Windows.Forms.Label();
            this.txtVariosDestinatarios = new System.Windows.Forms.TextBox();
            this.lblVariosDestinatarios = new System.Windows.Forms.Label();
            this.txtCobros = new System.Windows.Forms.TextBox();
            this.lblCobros = new System.Windows.Forms.Label();
            this.gbEntidadSucedida = new System.Windows.Forms.GroupBox();
            this.txtEntidadSucedidaNombreRazonSocial = new System.Windows.Forms.TextBox();
            this.lblEntidadSucedidaNombreRazonSocial = new System.Windows.Forms.Label();
            this.txtEntidadSucedidaNIF = new System.Windows.Forms.TextBox();
            this.lblEntidadSucedidaNIF = new System.Windows.Forms.Label();
            this.txtImporteTotal = new System.Windows.Forms.TextBox();
            this.lblImporteTotal = new System.Windows.Forms.Label();
            this.txtEmitidaPorTerceros = new System.Windows.Forms.TextBox();
            this.lblEmitidaPorTerceros = new System.Windows.Forms.Label();
            this.txtImporteTransmisionSujetoAIVA = new System.Windows.Forms.TextBox();
            this.lblImporteTransmisionSujetoAIVA = new System.Windows.Forms.Label();
            this.gbDatosInmueble = new System.Windows.Forms.GroupBox();
            this.txtReferenciaCatastral = new System.Windows.Forms.TextBox();
            this.lblReferenciaCatastral = new System.Windows.Forms.Label();
            this.txtSituacionInmueble = new System.Windows.Forms.TextBox();
            this.lblSituacionInmueble = new System.Windows.Forms.Label();
            this.txtDescripcionOperacion = new System.Windows.Forms.TextBox();
            this.lblDescripcionOperacion = new System.Windows.Forms.Label();
            this.txtBaseImponibleACoste = new System.Windows.Forms.TextBox();
            this.lblBaseImponibleACoste = new System.Windows.Forms.Label();
            this.txtClaveRegimenEspecialOTrascendencia = new System.Windows.Forms.TextBox();
            this.lblClaveRegimenEspecialOTrascendencia = new System.Windows.Forms.Label();
            this.txtFechaOperacion = new System.Windows.Forms.TextBox();
            this.lblFechaOperacion = new System.Windows.Forms.Label();
            this.gbImporteRectificacion = new System.Windows.Forms.GroupBox();
            this.txtImpRecCuotaRecargoRectificado = new System.Windows.Forms.TextBox();
            this.lblImpRecCuotaRecargoRectificado = new System.Windows.Forms.Label();
            this.txtImpRecCuotaRectificada = new System.Windows.Forms.TextBox();
            this.lblImpRecCuotaRectificada = new System.Windows.Forms.Label();
            this.txtImpRecBaseRectificada = new System.Windows.Forms.TextBox();
            this.lblImpRecBaseRectificada = new System.Windows.Forms.Label();
            this.gbFactRectificada = new System.Windows.Forms.GroupBox();
            this.txtRectificadaFechaExpedicionFacturaEmisor = new System.Windows.Forms.TextBox();
            this.lblRectificadaFechaExpedicionFacturaEmisor = new System.Windows.Forms.Label();
            this.txtlRectificadaNumSeriFacturaEmisor = new System.Windows.Forms.TextBox();
            this.lblRectificadaNumSeriFacturaEmisor = new System.Windows.Forms.Label();
            this.txtTipoRectificativa = new System.Windows.Forms.TextBox();
            this.lblTipoRectificativa = new System.Windows.Forms.Label();
            this.txtTipoFactura = new System.Windows.Forms.TextBox();
            this.lblTipoFactura = new System.Windows.Forms.Label();
            this.txtNumSerieFacturaEmisorResumenFin = new System.Windows.Forms.TextBox();
            this.lblNumSerieFacturaEmisorResumenFin = new System.Windows.Forms.Label();
            this.tabPageDesgloseFactura = new System.Windows.Forms.TabPage();
            this.gbDF_NoSujeta = new System.Windows.Forms.GroupBox();
            this.txtDF_NS_ImporteTAIReglasLocalizacion = new System.Windows.Forms.TextBox();
            this.lblDF_NS_ImporteTAIReglasLocalizacion = new System.Windows.Forms.Label();
            this.txtDF_NS_ImporteArticulos7_14_Otros = new System.Windows.Forms.TextBox();
            this.lblDF_NS_ImporteArticulos7_14_Otros = new System.Windows.Forms.Label();
            this.gbDF_Sujeta = new System.Windows.Forms.GroupBox();
            this.gbDF_SujetaNoExenta = new System.Windows.Forms.GroupBox();
            this.gbDF_SNE_DetalleIVA = new System.Windows.Forms.GroupBox();
            this.lblDF_SNE_NoExisteDetalleIVA = new System.Windows.Forms.Label();
            this.dgDF_SNE_DetalleIVA = new ObjectModel.TGGrid();
            this.txtDF_SNE_TipoNoExenta = new System.Windows.Forms.TextBox();
            this.lblDF_SNE_TipoNoExenta = new System.Windows.Forms.Label();
            this.gbDF_SujetaExenta = new System.Windows.Forms.GroupBox();
            this.lblDF_SE_NoExisteDetalleExenta = new System.Windows.Forms.Label();
            this.dgDF_SE_DetalleExenta = new ObjectModel.TGGrid();
            this.tabPagePrestacionServicios = new System.Windows.Forms.TabPage();
            this.gbDPS_NoSujeta = new System.Windows.Forms.GroupBox();
            this.txtDPS_NS_ImporteTAIReglasLocalizacion = new System.Windows.Forms.TextBox();
            this.lblDPS_NS_ImporteTAIReglasLocalizacion = new System.Windows.Forms.Label();
            this.txtDPS_NS_ImporteArticulos7_14_Otros = new System.Windows.Forms.TextBox();
            this.lblDPS_NS_ImporteArticulos7_14_Otros = new System.Windows.Forms.Label();
            this.gbDPS_Sujeta = new System.Windows.Forms.GroupBox();
            this.gbDPS_SujetaNoExenta = new System.Windows.Forms.GroupBox();
            this.gbDPS_SNE_DetalleIVA = new System.Windows.Forms.GroupBox();
            this.lblDPS_SNE_NoExisteDetalleIVA = new System.Windows.Forms.Label();
            this.dgDPS_SNE_DetalleIVA = new ObjectModel.TGGrid();
            this.txtDPS_SNE_TipoNoExenta = new System.Windows.Forms.TextBox();
            this.lblDPS_SNE_TipoNoExenta = new System.Windows.Forms.Label();
            this.gbDPS_SujetaExenta = new System.Windows.Forms.GroupBox();
            this.lblDPS_SE_NoExisteDetalleExenta = new System.Windows.Forms.Label();
            this.dgDPS_SE_DetalleExenta = new ObjectModel.TGGrid();
            this.tabPageEntrega = new System.Windows.Forms.TabPage();
            this.gbDE_NoSujeta = new System.Windows.Forms.GroupBox();
            this.txtDE_NS_ImporteTAIReglasLocalizacion = new System.Windows.Forms.TextBox();
            this.lblDE_NS_ImporteTAIReglasLocalizacion = new System.Windows.Forms.Label();
            this.txtDE_NS_ImporteArticulos7_14_Otros = new System.Windows.Forms.TextBox();
            this.lblDE_NS_ImporteArticulos7_14_Otros = new System.Windows.Forms.Label();
            this.gbDE_Sujeta = new System.Windows.Forms.GroupBox();
            this.gbDE_SujetaNoExenta = new System.Windows.Forms.GroupBox();
            this.gbDE_SNE_DetalleIVA = new System.Windows.Forms.GroupBox();
            this.lblDE_SNE_NoExisteDetalleIVA = new System.Windows.Forms.Label();
            this.dgDE_SNE_DetalleIVA = new ObjectModel.TGGrid();
            this.txtDE_SNE_TipoNoExenta = new System.Windows.Forms.TextBox();
            this.lblDE_SNE_TipoNoExenta = new System.Windows.Forms.Label();
            this.gbDE_SujetaExenta = new System.Windows.Forms.GroupBox();
            this.lblDE_SE_NoExisteDetalleExenta = new System.Windows.Forms.Label();
            this.dgDE_SE_DetalleExenta = new ObjectModel.TGGrid();
            this.gbCabecera.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tabControlFactura.SuspendLayout();
            this.tabPageDatosGrles.SuspendLayout();
            this.gbEntidadSucedida.SuspendLayout();
            this.gbDatosInmueble.SuspendLayout();
            this.gbImporteRectificacion.SuspendLayout();
            this.gbFactRectificada.SuspendLayout();
            this.tabPageDesgloseFactura.SuspendLayout();
            this.gbDF_NoSujeta.SuspendLayout();
            this.gbDF_Sujeta.SuspendLayout();
            this.gbDF_SujetaNoExenta.SuspendLayout();
            this.gbDF_SNE_DetalleIVA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDF_SNE_DetalleIVA)).BeginInit();
            this.gbDF_SujetaExenta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDF_SE_DetalleExenta)).BeginInit();
            this.tabPagePrestacionServicios.SuspendLayout();
            this.gbDPS_NoSujeta.SuspendLayout();
            this.gbDPS_Sujeta.SuspendLayout();
            this.gbDPS_SujetaNoExenta.SuspendLayout();
            this.gbDPS_SNE_DetalleIVA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDPS_SNE_DetalleIVA)).BeginInit();
            this.gbDPS_SujetaExenta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDPS_SE_DetalleExenta)).BeginInit();
            this.tabPageEntrega.SuspendLayout();
            this.gbDE_NoSujeta.SuspendLayout();
            this.gbDE_Sujeta.SuspendLayout();
            this.gbDE_SujetaNoExenta.SuspendLayout();
            this.gbDE_SNE_DetalleIVA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDE_SNE_DetalleIVA)).BeginInit();
            this.gbDE_SujetaExenta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDE_SE_DetalleExenta)).BeginInit();
            this.SuspendLayout();
            // 
            // gbCabecera
            // 
            this.gbCabecera.Controls.Add(this.txtNombreRazonSocialEmisorFact);
            this.gbCabecera.Controls.Add(this.lblNombreRazonSocialEmisorFact);
            this.gbCabecera.Controls.Add(this.txtEmisorFacturaNIF);
            this.gbCabecera.Controls.Add(this.lblEmisorFacturaNIF);
            this.gbCabecera.Controls.Add(this.txtFechaHoraEstadoCuadre);
            this.gbCabecera.Controls.Add(this.lblFechaHoraEstadoCuadre);
            this.gbCabecera.Controls.Add(this.txtProveedorNombreRazonSocial);
            this.gbCabecera.Controls.Add(this.lblProveedorNombreRazonSocial);
            this.gbCabecera.Controls.Add(this.txtEstadoCuadre);
            this.gbCabecera.Controls.Add(this.lblEstadoCudre);
            this.gbCabecera.Controls.Add(this.txtFechaDoc);
            this.gbCabecera.Controls.Add(this.lblFechaDoc);
            this.gbCabecera.Controls.Add(this.txtNoFact);
            this.gbCabecera.Controls.Add(this.lblFechaFactura);
            this.gbCabecera.Controls.Add(this.txtProveedorNIF);
            this.gbCabecera.Controls.Add(this.lblProveedorNIF);
            this.gbCabecera.Controls.Add(this.lblPeriodo);
            this.gbCabecera.Controls.Add(this.txtPeriodo);
            this.gbCabecera.Controls.Add(this.lblEjercicio);
            this.gbCabecera.Controls.Add(this.txtEjercicio);
            this.gbCabecera.Location = new System.Drawing.Point(35, 28);
            this.gbCabecera.Name = "gbCabecera";
            this.gbCabecera.Size = new System.Drawing.Size(907, 149);
            this.gbCabecera.TabIndex = 88;
            this.gbCabecera.TabStop = false;
            // 
            // txtNombreRazonSocialEmisorFact
            // 
            this.txtNombreRazonSocialEmisorFact.Location = new System.Drawing.Point(526, 64);
            this.txtNombreRazonSocialEmisorFact.Multiline = true;
            this.txtNombreRazonSocialEmisorFact.Name = "txtNombreRazonSocialEmisorFact";
            this.txtNombreRazonSocialEmisorFact.ReadOnly = true;
            this.txtNombreRazonSocialEmisorFact.Size = new System.Drawing.Size(354, 20);
            this.txtNombreRazonSocialEmisorFact.TabIndex = 107;
            // 
            // lblNombreRazonSocialEmisorFact
            // 
            this.lblNombreRazonSocialEmisorFact.AutoSize = true;
            this.lblNombreRazonSocialEmisorFact.Location = new System.Drawing.Point(323, 69);
            this.lblNombreRazonSocialEmisorFact.Name = "lblNombreRazonSocialEmisorFact";
            this.lblNombreRazonSocialEmisorFact.Size = new System.Drawing.Size(192, 13);
            this.lblNombreRazonSocialEmisorFact.TabIndex = 106;
            this.lblNombreRazonSocialEmisorFact.Text = "Nombre o Razón Social Emisor Factura";
            // 
            // txtEmisorFacturaNIF
            // 
            this.txtEmisorFacturaNIF.Location = new System.Drawing.Point(130, 64);
            this.txtEmisorFacturaNIF.Name = "txtEmisorFacturaNIF";
            this.txtEmisorFacturaNIF.ReadOnly = true;
            this.txtEmisorFacturaNIF.Size = new System.Drawing.Size(91, 20);
            this.txtEmisorFacturaNIF.TabIndex = 101;
            // 
            // lblEmisorFacturaNIF
            // 
            this.lblEmisorFacturaNIF.AutoSize = true;
            this.lblEmisorFacturaNIF.Location = new System.Drawing.Point(19, 69);
            this.lblEmisorFacturaNIF.Name = "lblEmisorFacturaNIF";
            this.lblEmisorFacturaNIF.Size = new System.Drawing.Size(97, 13);
            this.lblEmisorFacturaNIF.TabIndex = 100;
            this.lblEmisorFacturaNIF.Text = "NIF Emisor Factura";
            // 
            // txtFechaHoraEstadoCuadre
            // 
            this.txtFechaHoraEstadoCuadre.Location = new System.Drawing.Point(526, 115);
            this.txtFechaHoraEstadoCuadre.Name = "txtFechaHoraEstadoCuadre";
            this.txtFechaHoraEstadoCuadre.ReadOnly = true;
            this.txtFechaHoraEstadoCuadre.Size = new System.Drawing.Size(91, 20);
            this.txtFechaHoraEstadoCuadre.TabIndex = 99;
            // 
            // lblFechaHoraEstadoCuadre
            // 
            this.lblFechaHoraEstadoCuadre.AutoSize = true;
            this.lblFechaHoraEstadoCuadre.Location = new System.Drawing.Point(376, 117);
            this.lblFechaHoraEstadoCuadre.Name = "lblFechaHoraEstadoCuadre";
            this.lblFechaHoraEstadoCuadre.Size = new System.Drawing.Size(138, 13);
            this.lblFechaHoraEstadoCuadre.TabIndex = 98;
            this.lblFechaHoraEstadoCuadre.Text = "Fecha/Hora Estado Cuadre";
            // 
            // txtProveedorNombreRazonSocial
            // 
            this.txtProveedorNombreRazonSocial.Location = new System.Drawing.Point(526, 38);
            this.txtProveedorNombreRazonSocial.Multiline = true;
            this.txtProveedorNombreRazonSocial.Name = "txtProveedorNombreRazonSocial";
            this.txtProveedorNombreRazonSocial.ReadOnly = true;
            this.txtProveedorNombreRazonSocial.Size = new System.Drawing.Size(354, 20);
            this.txtProveedorNombreRazonSocial.TabIndex = 97;
            // 
            // lblProveedorNombreRazonSocial
            // 
            this.lblProveedorNombreRazonSocial.AutoSize = true;
            this.lblProveedorNombreRazonSocial.Location = new System.Drawing.Point(343, 43);
            this.lblProveedorNombreRazonSocial.Name = "lblProveedorNombreRazonSocial";
            this.lblProveedorNombreRazonSocial.Size = new System.Drawing.Size(171, 13);
            this.lblProveedorNombreRazonSocial.TabIndex = 96;
            this.lblProveedorNombreRazonSocial.Text = "Nombre o Razón Social Proveedor";
            // 
            // txtEstadoCuadre
            // 
            this.txtEstadoCuadre.Location = new System.Drawing.Point(130, 115);
            this.txtEstadoCuadre.Name = "txtEstadoCuadre";
            this.txtEstadoCuadre.ReadOnly = true;
            this.txtEstadoCuadre.Size = new System.Drawing.Size(172, 20);
            this.txtEstadoCuadre.TabIndex = 95;
            // 
            // lblEstadoCudre
            // 
            this.lblEstadoCudre.AutoSize = true;
            this.lblEstadoCudre.Location = new System.Drawing.Point(19, 117);
            this.lblEstadoCudre.Name = "lblEstadoCudre";
            this.lblEstadoCudre.Size = new System.Drawing.Size(77, 13);
            this.lblEstadoCudre.TabIndex = 94;
            this.lblEstadoCudre.Text = "Estado Cuadre";
            // 
            // txtFechaDoc
            // 
            this.txtFechaDoc.Location = new System.Drawing.Point(526, 90);
            this.txtFechaDoc.Name = "txtFechaDoc";
            this.txtFechaDoc.ReadOnly = true;
            this.txtFechaDoc.Size = new System.Drawing.Size(91, 20);
            this.txtFechaDoc.TabIndex = 93;
            // 
            // lblFechaDoc
            // 
            this.lblFechaDoc.AutoSize = true;
            this.lblFechaDoc.Location = new System.Drawing.Point(419, 93);
            this.lblFechaDoc.Name = "lblFechaDoc";
            this.lblFechaDoc.Size = new System.Drawing.Size(95, 13);
            this.lblFechaDoc.TabIndex = 92;
            this.lblFechaDoc.Text = "Fecha Documento";
            // 
            // txtNoFact
            // 
            this.txtNoFact.Location = new System.Drawing.Point(130, 90);
            this.txtNoFact.Name = "txtNoFact";
            this.txtNoFact.ReadOnly = true;
            this.txtNoFact.Size = new System.Drawing.Size(134, 20);
            this.txtNoFact.TabIndex = 91;
            // 
            // lblFechaFactura
            // 
            this.lblFechaFactura.AutoSize = true;
            this.lblFechaFactura.Location = new System.Drawing.Point(19, 93);
            this.lblFechaFactura.Name = "lblFechaFactura";
            this.lblFechaFactura.Size = new System.Drawing.Size(63, 13);
            this.lblFechaFactura.TabIndex = 90;
            this.lblFechaFactura.Text = "No. Factura";
            // 
            // txtProveedorNIF
            // 
            this.txtProveedorNIF.Location = new System.Drawing.Point(130, 38);
            this.txtProveedorNIF.Name = "txtProveedorNIF";
            this.txtProveedorNIF.ReadOnly = true;
            this.txtProveedorNIF.Size = new System.Drawing.Size(91, 20);
            this.txtProveedorNIF.TabIndex = 89;
            // 
            // lblProveedorNIF
            // 
            this.lblProveedorNIF.AutoSize = true;
            this.lblProveedorNIF.Location = new System.Drawing.Point(19, 43);
            this.lblProveedorNIF.Name = "lblProveedorNIF";
            this.lblProveedorNIF.Size = new System.Drawing.Size(76, 13);
            this.lblProveedorNIF.TabIndex = 88;
            this.lblProveedorNIF.Text = "NIF Proveedor";
            // 
            // lblPeriodo
            // 
            this.lblPeriodo.AutoSize = true;
            this.lblPeriodo.Location = new System.Drawing.Point(471, 17);
            this.lblPeriodo.Name = "lblPeriodo";
            this.lblPeriodo.Size = new System.Drawing.Size(43, 13);
            this.lblPeriodo.TabIndex = 86;
            this.lblPeriodo.Text = "Periodo";
            // 
            // txtPeriodo
            // 
            this.txtPeriodo.Location = new System.Drawing.Point(526, 14);
            this.txtPeriodo.Name = "txtPeriodo";
            this.txtPeriodo.ReadOnly = true;
            this.txtPeriodo.Size = new System.Drawing.Size(23, 20);
            this.txtPeriodo.TabIndex = 87;
            // 
            // lblEjercicio
            // 
            this.lblEjercicio.AutoSize = true;
            this.lblEjercicio.Location = new System.Drawing.Point(19, 17);
            this.lblEjercicio.Name = "lblEjercicio";
            this.lblEjercicio.Size = new System.Drawing.Size(47, 13);
            this.lblEjercicio.TabIndex = 84;
            this.lblEjercicio.Text = "Ejercicio";
            // 
            // txtEjercicio
            // 
            this.txtEjercicio.Location = new System.Drawing.Point(130, 14);
            this.txtEjercicio.Name = "txtEjercicio";
            this.txtEjercicio.ReadOnly = true;
            this.txtEjercicio.Size = new System.Drawing.Size(38, 20);
            this.txtEjercicio.TabIndex = 85;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.LightCyan;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonSalir});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1003, 25);
            this.toolStrip1.TabIndex = 82;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonSalir
            // 
            this.toolStripButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSalir.Image")));
            this.toolStripButtonSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSalir.Name = "toolStripButtonSalir";
            this.toolStripButtonSalir.Size = new System.Drawing.Size(49, 22);
            this.toolStripButtonSalir.Text = "&Salir";
            this.toolStripButtonSalir.Click += new System.EventHandler(this.toolStripButtonSalir_Click);
            // 
            // tabControlFactura
            // 
            this.tabControlFactura.Controls.Add(this.tabPageDatosGrles);
            this.tabControlFactura.Controls.Add(this.tabPageDesgloseFactura);
            this.tabControlFactura.Controls.Add(this.tabPagePrestacionServicios);
            this.tabControlFactura.Controls.Add(this.tabPageEntrega);
            this.tabControlFactura.Location = new System.Drawing.Point(35, 185);
            this.tabControlFactura.Name = "tabControlFactura";
            this.tabControlFactura.SelectedIndex = 0;
            this.tabControlFactura.Size = new System.Drawing.Size(911, 497);
            this.tabControlFactura.TabIndex = 83;
            // 
            // tabPageDatosGrles
            // 
            this.tabPageDatosGrles.AutoScroll = true;
            this.tabPageDatosGrles.Controls.Add(this.txtFacturaSinIdentifDestinatarioArticulo61d);
            this.tabPageDatosGrles.Controls.Add(this.lblFacturaSinIdentifDestinatarioArticulo61d);
            this.tabPageDatosGrles.Controls.Add(this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas);
            this.tabPageDatosGrles.Controls.Add(this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas);
            this.tabPageDatosGrles.Controls.Add(this.txtMacrodato);
            this.tabPageDatosGrles.Controls.Add(this.lblMacrodato);
            this.tabPageDatosGrles.Controls.Add(this.txtRegistroPrevioGGEEoREDEMEoCompetencia);
            this.tabPageDatosGrles.Controls.Add(this.lblRegistroPrevioGGEEoREDEMEoCompetencia);
            this.tabPageDatosGrles.Controls.Add(this.txtFactSimplificadaArticulos72_73);
            this.tabPageDatosGrles.Controls.Add(this.lblFactSimplificadaArticulos72_73);
            this.tabPageDatosGrles.Controls.Add(this.txtRefExterna);
            this.tabPageDatosGrles.Controls.Add(this.lblRefExterna);
            this.tabPageDatosGrles.Controls.Add(this.txtNumRegistroAcuerdoFacturacion);
            this.tabPageDatosGrles.Controls.Add(this.lblNumRegistroAcuerdoFacturacion);
            this.tabPageDatosGrles.Controls.Add(this.txtClaveRegimenEspecialOTrasAdicional2);
            this.tabPageDatosGrles.Controls.Add(this.lblClaveRegimenEspecialOTrasAdicional2);
            this.tabPageDatosGrles.Controls.Add(this.txtClaveRegimenEspecialOTrasAdicional1);
            this.tabPageDatosGrles.Controls.Add(this.lblClaveRegimenEspecialOTrasAdicional1);
            this.tabPageDatosGrles.Controls.Add(this.txtCupon);
            this.tabPageDatosGrles.Controls.Add(this.lblCupon);
            this.tabPageDatosGrles.Controls.Add(this.txtVariosDestinatarios);
            this.tabPageDatosGrles.Controls.Add(this.lblVariosDestinatarios);
            this.tabPageDatosGrles.Controls.Add(this.txtCobros);
            this.tabPageDatosGrles.Controls.Add(this.lblCobros);
            this.tabPageDatosGrles.Controls.Add(this.gbEntidadSucedida);
            this.tabPageDatosGrles.Controls.Add(this.txtImporteTotal);
            this.tabPageDatosGrles.Controls.Add(this.lblImporteTotal);
            this.tabPageDatosGrles.Controls.Add(this.txtEmitidaPorTerceros);
            this.tabPageDatosGrles.Controls.Add(this.lblEmitidaPorTerceros);
            this.tabPageDatosGrles.Controls.Add(this.txtImporteTransmisionSujetoAIVA);
            this.tabPageDatosGrles.Controls.Add(this.lblImporteTransmisionSujetoAIVA);
            this.tabPageDatosGrles.Controls.Add(this.gbDatosInmueble);
            this.tabPageDatosGrles.Controls.Add(this.txtDescripcionOperacion);
            this.tabPageDatosGrles.Controls.Add(this.lblDescripcionOperacion);
            this.tabPageDatosGrles.Controls.Add(this.txtBaseImponibleACoste);
            this.tabPageDatosGrles.Controls.Add(this.lblBaseImponibleACoste);
            this.tabPageDatosGrles.Controls.Add(this.txtClaveRegimenEspecialOTrascendencia);
            this.tabPageDatosGrles.Controls.Add(this.lblClaveRegimenEspecialOTrascendencia);
            this.tabPageDatosGrles.Controls.Add(this.txtFechaOperacion);
            this.tabPageDatosGrles.Controls.Add(this.lblFechaOperacion);
            this.tabPageDatosGrles.Controls.Add(this.gbImporteRectificacion);
            this.tabPageDatosGrles.Controls.Add(this.gbFactRectificada);
            this.tabPageDatosGrles.Controls.Add(this.txtTipoRectificativa);
            this.tabPageDatosGrles.Controls.Add(this.lblTipoRectificativa);
            this.tabPageDatosGrles.Controls.Add(this.txtTipoFactura);
            this.tabPageDatosGrles.Controls.Add(this.lblTipoFactura);
            this.tabPageDatosGrles.Controls.Add(this.txtNumSerieFacturaEmisorResumenFin);
            this.tabPageDatosGrles.Controls.Add(this.lblNumSerieFacturaEmisorResumenFin);
            this.tabPageDatosGrles.Location = new System.Drawing.Point(4, 22);
            this.tabPageDatosGrles.Name = "tabPageDatosGrles";
            this.tabPageDatosGrles.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDatosGrles.Size = new System.Drawing.Size(903, 471);
            this.tabPageDatosGrles.TabIndex = 0;
            this.tabPageDatosGrles.Text = "Datos Generales";
            this.tabPageDatosGrles.UseVisualStyleBackColor = true;
            // 
            // txtFacturaSinIdentifDestinatarioArticulo61d
            // 
            this.txtFacturaSinIdentifDestinatarioArticulo61d.Location = new System.Drawing.Point(709, 417);
            this.txtFacturaSinIdentifDestinatarioArticulo61d.Name = "txtFacturaSinIdentifDestinatarioArticulo61d";
            this.txtFacturaSinIdentifDestinatarioArticulo61d.ReadOnly = true;
            this.txtFacturaSinIdentifDestinatarioArticulo61d.Size = new System.Drawing.Size(167, 20);
            this.txtFacturaSinIdentifDestinatarioArticulo61d.TabIndex = 143;
            // 
            // lblFacturaSinIdentifDestinatarioArticulo61d
            // 
            this.lblFacturaSinIdentifDestinatarioArticulo61d.AutoSize = true;
            this.lblFacturaSinIdentifDestinatarioArticulo61d.Location = new System.Drawing.Point(453, 421);
            this.lblFacturaSinIdentifDestinatarioArticulo61d.MinimumSize = new System.Drawing.Size(40, 0);
            this.lblFacturaSinIdentifDestinatarioArticulo61d.Name = "lblFacturaSinIdentifDestinatarioArticulo61d";
            this.lblFacturaSinIdentifDestinatarioArticulo61d.Size = new System.Drawing.Size(219, 13);
            this.lblFacturaSinIdentifDestinatarioArticulo61d.TabIndex = 142;
            this.lblFacturaSinIdentifDestinatarioArticulo61d.Text = "Factura Sin Identif Destinatario Artículo 6.1.d";
            // 
            // txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas
            // 
            this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Location = new System.Drawing.Point(709, 366);
            this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Name = "txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas";
            this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.ReadOnly = true;
            this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Size = new System.Drawing.Size(167, 20);
            this.txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.TabIndex = 141;
            // 
            // lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas
            // 
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.AutoSize = true;
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Location = new System.Drawing.Point(453, 366);
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.MaximumSize = new System.Drawing.Size(350, 0);
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Name = "lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas";
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Size = new System.Drawing.Size(198, 13);
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.TabIndex = 140;
            this.lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas.Text = "Fact. Disp. Adic. 3a y 6a y Mercado Gas";
            // 
            // txtMacrodato
            // 
            this.txtMacrodato.Location = new System.Drawing.Point(709, 315);
            this.txtMacrodato.Name = "txtMacrodato";
            this.txtMacrodato.ReadOnly = true;
            this.txtMacrodato.Size = new System.Drawing.Size(167, 20);
            this.txtMacrodato.TabIndex = 139;
            // 
            // lblMacrodato
            // 
            this.lblMacrodato.AutoSize = true;
            this.lblMacrodato.Location = new System.Drawing.Point(453, 317);
            this.lblMacrodato.Name = "lblMacrodato";
            this.lblMacrodato.Size = new System.Drawing.Size(58, 13);
            this.lblMacrodato.TabIndex = 138;
            this.lblMacrodato.Text = "Macrodato";
            // 
            // txtRegistroPrevioGGEEoREDEMEoCompetencia
            // 
            this.txtRegistroPrevioGGEEoREDEMEoCompetencia.Location = new System.Drawing.Point(709, 290);
            this.txtRegistroPrevioGGEEoREDEMEoCompetencia.Name = "txtRegistroPrevioGGEEoREDEMEoCompetencia";
            this.txtRegistroPrevioGGEEoREDEMEoCompetencia.ReadOnly = true;
            this.txtRegistroPrevioGGEEoREDEMEoCompetencia.Size = new System.Drawing.Size(167, 20);
            this.txtRegistroPrevioGGEEoREDEMEoCompetencia.TabIndex = 137;
            // 
            // lblRegistroPrevioGGEEoREDEMEoCompetencia
            // 
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia.AutoSize = true;
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia.Location = new System.Drawing.Point(453, 291);
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia.Name = "lblRegistroPrevioGGEEoREDEMEoCompetencia";
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia.Size = new System.Drawing.Size(221, 13);
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia.TabIndex = 136;
            this.lblRegistroPrevioGGEEoREDEMEoCompetencia.Text = "Registro Previo GGEE o REDEME o Compet.";
            // 
            // txtFactSimplificadaArticulos72_73
            // 
            this.txtFactSimplificadaArticulos72_73.Location = new System.Drawing.Point(709, 265);
            this.txtFactSimplificadaArticulos72_73.Name = "txtFactSimplificadaArticulos72_73";
            this.txtFactSimplificadaArticulos72_73.ReadOnly = true;
            this.txtFactSimplificadaArticulos72_73.Size = new System.Drawing.Size(167, 20);
            this.txtFactSimplificadaArticulos72_73.TabIndex = 135;
            // 
            // lblFactSimplificadaArticulos72_73
            // 
            this.lblFactSimplificadaArticulos72_73.AutoSize = true;
            this.lblFactSimplificadaArticulos72_73.Location = new System.Drawing.Point(453, 266);
            this.lblFactSimplificadaArticulos72_73.Name = "lblFactSimplificadaArticulos72_73";
            this.lblFactSimplificadaArticulos72_73.Size = new System.Drawing.Size(194, 13);
            this.lblFactSimplificadaArticulos72_73.TabIndex = 134;
            this.lblFactSimplificadaArticulos72_73.Text = "Factura Simplificada Artículos 7.2  y 7.3";
            // 
            // txtRefExterna
            // 
            this.txtRefExterna.Location = new System.Drawing.Point(246, 415);
            this.txtRefExterna.Name = "txtRefExterna";
            this.txtRefExterna.ReadOnly = true;
            this.txtRefExterna.Size = new System.Drawing.Size(167, 20);
            this.txtRefExterna.TabIndex = 133;
            // 
            // lblRefExterna
            // 
            this.lblRefExterna.AutoSize = true;
            this.lblRefExterna.Location = new System.Drawing.Point(22, 416);
            this.lblRefExterna.Name = "lblRefExterna";
            this.lblRefExterna.Size = new System.Drawing.Size(98, 13);
            this.lblRefExterna.TabIndex = 132;
            this.lblRefExterna.Text = "Referencia Externa";
            // 
            // txtNumRegistroAcuerdoFacturacion
            // 
            this.txtNumRegistroAcuerdoFacturacion.Location = new System.Drawing.Point(246, 365);
            this.txtNumRegistroAcuerdoFacturacion.Name = "txtNumRegistroAcuerdoFacturacion";
            this.txtNumRegistroAcuerdoFacturacion.ReadOnly = true;
            this.txtNumRegistroAcuerdoFacturacion.Size = new System.Drawing.Size(167, 20);
            this.txtNumRegistroAcuerdoFacturacion.TabIndex = 131;
            // 
            // lblNumRegistroAcuerdoFacturacion
            // 
            this.lblNumRegistroAcuerdoFacturacion.AutoSize = true;
            this.lblNumRegistroAcuerdoFacturacion.Location = new System.Drawing.Point(22, 368);
            this.lblNumRegistroAcuerdoFacturacion.Name = "lblNumRegistroAcuerdoFacturacion";
            this.lblNumRegistroAcuerdoFacturacion.Size = new System.Drawing.Size(188, 13);
            this.lblNumRegistroAcuerdoFacturacion.TabIndex = 130;
            this.lblNumRegistroAcuerdoFacturacion.Text = "Número Registro Acuerdo Facturación";
            // 
            // txtClaveRegimenEspecialOTrasAdicional2
            // 
            this.txtClaveRegimenEspecialOTrasAdicional2.Location = new System.Drawing.Point(246, 341);
            this.txtClaveRegimenEspecialOTrasAdicional2.Name = "txtClaveRegimenEspecialOTrasAdicional2";
            this.txtClaveRegimenEspecialOTrasAdicional2.ReadOnly = true;
            this.txtClaveRegimenEspecialOTrasAdicional2.Size = new System.Drawing.Size(167, 20);
            this.txtClaveRegimenEspecialOTrasAdicional2.TabIndex = 129;
            // 
            // lblClaveRegimenEspecialOTrasAdicional2
            // 
            this.lblClaveRegimenEspecialOTrasAdicional2.AutoSize = true;
            this.lblClaveRegimenEspecialOTrasAdicional2.Location = new System.Drawing.Point(22, 344);
            this.lblClaveRegimenEspecialOTrasAdicional2.Name = "lblClaveRegimenEspecialOTrasAdicional2";
            this.lblClaveRegimenEspecialOTrasAdicional2.Size = new System.Drawing.Size(213, 13);
            this.lblClaveRegimenEspecialOTrasAdicional2.TabIndex = 128;
            this.lblClaveRegimenEspecialOTrasAdicional2.Text = "Clave Regimen Especial o Tras. Adicional 2";
            // 
            // txtClaveRegimenEspecialOTrasAdicional1
            // 
            this.txtClaveRegimenEspecialOTrasAdicional1.Location = new System.Drawing.Point(246, 316);
            this.txtClaveRegimenEspecialOTrasAdicional1.Name = "txtClaveRegimenEspecialOTrasAdicional1";
            this.txtClaveRegimenEspecialOTrasAdicional1.ReadOnly = true;
            this.txtClaveRegimenEspecialOTrasAdicional1.Size = new System.Drawing.Size(167, 20);
            this.txtClaveRegimenEspecialOTrasAdicional1.TabIndex = 127;
            // 
            // lblClaveRegimenEspecialOTrasAdicional1
            // 
            this.lblClaveRegimenEspecialOTrasAdicional1.AutoSize = true;
            this.lblClaveRegimenEspecialOTrasAdicional1.Location = new System.Drawing.Point(22, 319);
            this.lblClaveRegimenEspecialOTrasAdicional1.Name = "lblClaveRegimenEspecialOTrasAdicional1";
            this.lblClaveRegimenEspecialOTrasAdicional1.Size = new System.Drawing.Size(213, 13);
            this.lblClaveRegimenEspecialOTrasAdicional1.TabIndex = 126;
            this.lblClaveRegimenEspecialOTrasAdicional1.Text = "Clave Regimen Especial o Tras. Adicional 1";
            // 
            // txtCupon
            // 
            this.txtCupon.Location = new System.Drawing.Point(709, 213);
            this.txtCupon.Name = "txtCupon";
            this.txtCupon.ReadOnly = true;
            this.txtCupon.Size = new System.Drawing.Size(167, 20);
            this.txtCupon.TabIndex = 34;
            // 
            // lblCupon
            // 
            this.lblCupon.AutoSize = true;
            this.lblCupon.Location = new System.Drawing.Point(453, 215);
            this.lblCupon.Name = "lblCupon";
            this.lblCupon.Size = new System.Drawing.Size(38, 13);
            this.lblCupon.TabIndex = 33;
            this.lblCupon.Text = "Cupón";
            // 
            // txtVariosDestinatarios
            // 
            this.txtVariosDestinatarios.Location = new System.Drawing.Point(709, 188);
            this.txtVariosDestinatarios.Name = "txtVariosDestinatarios";
            this.txtVariosDestinatarios.ReadOnly = true;
            this.txtVariosDestinatarios.Size = new System.Drawing.Size(167, 20);
            this.txtVariosDestinatarios.TabIndex = 32;
            // 
            // lblVariosDestinatarios
            // 
            this.lblVariosDestinatarios.AutoSize = true;
            this.lblVariosDestinatarios.Location = new System.Drawing.Point(453, 191);
            this.lblVariosDestinatarios.Name = "lblVariosDestinatarios";
            this.lblVariosDestinatarios.Size = new System.Drawing.Size(100, 13);
            this.lblVariosDestinatarios.TabIndex = 31;
            this.lblVariosDestinatarios.Text = "Varios Destinatarios";
            // 
            // txtCobros
            // 
            this.txtCobros.Location = new System.Drawing.Point(709, 392);
            this.txtCobros.Name = "txtCobros";
            this.txtCobros.ReadOnly = true;
            this.txtCobros.Size = new System.Drawing.Size(167, 20);
            this.txtCobros.TabIndex = 115;
            // 
            // lblCobros
            // 
            this.lblCobros.AutoSize = true;
            this.lblCobros.Location = new System.Drawing.Point(453, 395);
            this.lblCobros.Name = "lblCobros";
            this.lblCobros.Size = new System.Drawing.Size(72, 13);
            this.lblCobros.TabIndex = 110;
            this.lblCobros.Text = "Cobros RECC";
            // 
            // gbEntidadSucedida
            // 
            this.gbEntidadSucedida.Controls.Add(this.txtEntidadSucedidaNombreRazonSocial);
            this.gbEntidadSucedida.Controls.Add(this.lblEntidadSucedidaNombreRazonSocial);
            this.gbEntidadSucedida.Controls.Add(this.txtEntidadSucedidaNIF);
            this.gbEntidadSucedida.Controls.Add(this.lblEntidadSucedidaNIF);
            this.gbEntidadSucedida.Location = new System.Drawing.Point(444, 89);
            this.gbEntidadSucedida.Name = "gbEntidadSucedida";
            this.gbEntidadSucedida.Size = new System.Drawing.Size(453, 69);
            this.gbEntidadSucedida.TabIndex = 12;
            this.gbEntidadSucedida.TabStop = false;
            this.gbEntidadSucedida.Text = " Entidad Sucedida ";
            // 
            // txtEntidadSucedidaNombreRazonSocial
            // 
            this.txtEntidadSucedidaNombreRazonSocial.Location = new System.Drawing.Point(142, 40);
            this.txtEntidadSucedidaNombreRazonSocial.Name = "txtEntidadSucedidaNombreRazonSocial";
            this.txtEntidadSucedidaNombreRazonSocial.ReadOnly = true;
            this.txtEntidadSucedidaNombreRazonSocial.Size = new System.Drawing.Size(305, 20);
            this.txtEntidadSucedidaNombreRazonSocial.TabIndex = 10;
            // 
            // lblEntidadSucedidaNombreRazonSocial
            // 
            this.lblEntidadSucedidaNombreRazonSocial.AutoSize = true;
            this.lblEntidadSucedidaNombreRazonSocial.Location = new System.Drawing.Point(9, 44);
            this.lblEntidadSucedidaNombreRazonSocial.Name = "lblEntidadSucedidaNombreRazonSocial";
            this.lblEntidadSucedidaNombreRazonSocial.Size = new System.Drawing.Size(119, 13);
            this.lblEntidadSucedidaNombreRazonSocial.TabIndex = 9;
            this.lblEntidadSucedidaNombreRazonSocial.Text = "Nombre o Razón Social";
            // 
            // txtEntidadSucedidaNIF
            // 
            this.txtEntidadSucedidaNIF.Location = new System.Drawing.Point(142, 16);
            this.txtEntidadSucedidaNIF.Name = "txtEntidadSucedidaNIF";
            this.txtEntidadSucedidaNIF.ReadOnly = true;
            this.txtEntidadSucedidaNIF.Size = new System.Drawing.Size(167, 20);
            this.txtEntidadSucedidaNIF.TabIndex = 8;
            // 
            // lblEntidadSucedidaNIF
            // 
            this.lblEntidadSucedidaNIF.AutoSize = true;
            this.lblEntidadSucedidaNIF.Location = new System.Drawing.Point(9, 21);
            this.lblEntidadSucedidaNIF.Name = "lblEntidadSucedidaNIF";
            this.lblEntidadSucedidaNIF.Size = new System.Drawing.Size(24, 13);
            this.lblEntidadSucedidaNIF.TabIndex = 6;
            this.lblEntidadSucedidaNIF.Text = "NIF";
            // 
            // txtImporteTotal
            // 
            this.txtImporteTotal.Location = new System.Drawing.Point(246, 43);
            this.txtImporteTotal.Name = "txtImporteTotal";
            this.txtImporteTotal.ReadOnly = true;
            this.txtImporteTotal.Size = new System.Drawing.Size(167, 20);
            this.txtImporteTotal.TabIndex = 20;
            // 
            // lblImporteTotal
            // 
            this.lblImporteTotal.AutoSize = true;
            this.lblImporteTotal.Location = new System.Drawing.Point(22, 45);
            this.lblImporteTotal.Name = "lblImporteTotal";
            this.lblImporteTotal.Size = new System.Drawing.Size(69, 13);
            this.lblImporteTotal.TabIndex = 15;
            this.lblImporteTotal.Text = "Importe Total";
            // 
            // txtEmitidaPorTerceros
            // 
            this.txtEmitidaPorTerceros.Location = new System.Drawing.Point(709, 163);
            this.txtEmitidaPorTerceros.Name = "txtEmitidaPorTerceros";
            this.txtEmitidaPorTerceros.ReadOnly = true;
            this.txtEmitidaPorTerceros.Size = new System.Drawing.Size(167, 20);
            this.txtEmitidaPorTerceros.TabIndex = 95;
            // 
            // lblEmitidaPorTerceros
            // 
            this.lblEmitidaPorTerceros.AutoSize = true;
            this.lblEmitidaPorTerceros.Location = new System.Drawing.Point(453, 165);
            this.lblEmitidaPorTerceros.Name = "lblEmitidaPorTerceros";
            this.lblEmitidaPorTerceros.Size = new System.Drawing.Size(173, 13);
            this.lblEmitidaPorTerceros.TabIndex = 90;
            this.lblEmitidaPorTerceros.Text = "Emitida Por Terceros o Destinatario";
            // 
            // txtImporteTransmisionSujetoAIVA
            // 
            this.txtImporteTransmisionSujetoAIVA.Location = new System.Drawing.Point(709, 340);
            this.txtImporteTransmisionSujetoAIVA.Name = "txtImporteTransmisionSujetoAIVA";
            this.txtImporteTransmisionSujetoAIVA.ReadOnly = true;
            this.txtImporteTransmisionSujetoAIVA.Size = new System.Drawing.Size(167, 20);
            this.txtImporteTransmisionSujetoAIVA.TabIndex = 85;
            // 
            // lblImporteTransmisionSujetoAIVA
            // 
            this.lblImporteTransmisionSujetoAIVA.AutoSize = true;
            this.lblImporteTransmisionSujetoAIVA.Location = new System.Drawing.Point(453, 342);
            this.lblImporteTransmisionSujetoAIVA.Name = "lblImporteTransmisionSujetoAIVA";
            this.lblImporteTransmisionSujetoAIVA.Size = new System.Drawing.Size(214, 13);
            this.lblImporteTransmisionSujetoAIVA.TabIndex = 80;
            this.lblImporteTransmisionSujetoAIVA.Text = "Importe Transmisión Inmuebles Sujeto a IVA";
            // 
            // gbDatosInmueble
            // 
            this.gbDatosInmueble.Controls.Add(this.txtReferenciaCatastral);
            this.gbDatosInmueble.Controls.Add(this.lblReferenciaCatastral);
            this.gbDatosInmueble.Controls.Add(this.txtSituacionInmueble);
            this.gbDatosInmueble.Controls.Add(this.lblSituacionInmueble);
            this.gbDatosInmueble.Location = new System.Drawing.Point(444, 14);
            this.gbDatosInmueble.Name = "gbDatosInmueble";
            this.gbDatosInmueble.Size = new System.Drawing.Size(453, 69);
            this.gbDatosInmueble.TabIndex = 11;
            this.gbDatosInmueble.TabStop = false;
            this.gbDatosInmueble.Text = " Datos Inmueble ";
            // 
            // txtReferenciaCatastral
            // 
            this.txtReferenciaCatastral.Location = new System.Drawing.Point(142, 40);
            this.txtReferenciaCatastral.Name = "txtReferenciaCatastral";
            this.txtReferenciaCatastral.ReadOnly = true;
            this.txtReferenciaCatastral.Size = new System.Drawing.Size(167, 20);
            this.txtReferenciaCatastral.TabIndex = 10;
            // 
            // lblReferenciaCatastral
            // 
            this.lblReferenciaCatastral.AutoSize = true;
            this.lblReferenciaCatastral.Location = new System.Drawing.Point(9, 44);
            this.lblReferenciaCatastral.Name = "lblReferenciaCatastral";
            this.lblReferenciaCatastral.Size = new System.Drawing.Size(103, 13);
            this.lblReferenciaCatastral.TabIndex = 9;
            this.lblReferenciaCatastral.Text = "Referencia Catastral";
            // 
            // txtSituacionInmueble
            // 
            this.txtSituacionInmueble.Location = new System.Drawing.Point(142, 16);
            this.txtSituacionInmueble.Name = "txtSituacionInmueble";
            this.txtSituacionInmueble.ReadOnly = true;
            this.txtSituacionInmueble.Size = new System.Drawing.Size(167, 20);
            this.txtSituacionInmueble.TabIndex = 8;
            // 
            // lblSituacionInmueble
            // 
            this.lblSituacionInmueble.AutoSize = true;
            this.lblSituacionInmueble.Location = new System.Drawing.Point(9, 21);
            this.lblSituacionInmueble.Name = "lblSituacionInmueble";
            this.lblSituacionInmueble.Size = new System.Drawing.Size(97, 13);
            this.lblSituacionInmueble.TabIndex = 6;
            this.lblSituacionInmueble.Text = "Situación Inmueble";
            // 
            // txtDescripcionOperacion
            // 
            this.txtDescripcionOperacion.Location = new System.Drawing.Point(246, 440);
            this.txtDescripcionOperacion.Name = "txtDescripcionOperacion";
            this.txtDescripcionOperacion.ReadOnly = true;
            this.txtDescripcionOperacion.Size = new System.Drawing.Size(630, 20);
            this.txtDescripcionOperacion.TabIndex = 125;
            // 
            // lblDescripcionOperacion
            // 
            this.lblDescripcionOperacion.AutoSize = true;
            this.lblDescripcionOperacion.Location = new System.Drawing.Point(22, 442);
            this.lblDescripcionOperacion.Name = "lblDescripcionOperacion";
            this.lblDescripcionOperacion.Size = new System.Drawing.Size(115, 13);
            this.lblDescripcionOperacion.TabIndex = 120;
            this.lblDescripcionOperacion.Text = "Descripción Operación";
            // 
            // txtBaseImponibleACoste
            // 
            this.txtBaseImponibleACoste.Location = new System.Drawing.Point(246, 390);
            this.txtBaseImponibleACoste.Name = "txtBaseImponibleACoste";
            this.txtBaseImponibleACoste.ReadOnly = true;
            this.txtBaseImponibleACoste.Size = new System.Drawing.Size(167, 20);
            this.txtBaseImponibleACoste.TabIndex = 75;
            // 
            // lblBaseImponibleACoste
            // 
            this.lblBaseImponibleACoste.AutoSize = true;
            this.lblBaseImponibleACoste.Location = new System.Drawing.Point(22, 392);
            this.lblBaseImponibleACoste.Name = "lblBaseImponibleACoste";
            this.lblBaseImponibleACoste.Size = new System.Drawing.Size(118, 13);
            this.lblBaseImponibleACoste.TabIndex = 70;
            this.lblBaseImponibleACoste.Text = "Base Imponible a Coste";
            // 
            // txtClaveRegimenEspecialOTrascendencia
            // 
            this.txtClaveRegimenEspecialOTrascendencia.Location = new System.Drawing.Point(246, 291);
            this.txtClaveRegimenEspecialOTrascendencia.Name = "txtClaveRegimenEspecialOTrascendencia";
            this.txtClaveRegimenEspecialOTrascendencia.ReadOnly = true;
            this.txtClaveRegimenEspecialOTrascendencia.Size = new System.Drawing.Size(167, 20);
            this.txtClaveRegimenEspecialOTrascendencia.TabIndex = 65;
            // 
            // lblClaveRegimenEspecialOTrascendencia
            // 
            this.lblClaveRegimenEspecialOTrascendencia.AutoSize = true;
            this.lblClaveRegimenEspecialOTrascendencia.Location = new System.Drawing.Point(22, 294);
            this.lblClaveRegimenEspecialOTrascendencia.Name = "lblClaveRegimenEspecialOTrascendencia";
            this.lblClaveRegimenEspecialOTrascendencia.Size = new System.Drawing.Size(207, 13);
            this.lblClaveRegimenEspecialOTrascendencia.TabIndex = 60;
            this.lblClaveRegimenEspecialOTrascendencia.Text = "Clave Regimen Especial O Trascendencia";
            // 
            // txtFechaOperacion
            // 
            this.txtFechaOperacion.Location = new System.Drawing.Point(246, 266);
            this.txtFechaOperacion.Name = "txtFechaOperacion";
            this.txtFechaOperacion.ReadOnly = true;
            this.txtFechaOperacion.Size = new System.Drawing.Size(167, 20);
            this.txtFechaOperacion.TabIndex = 55;
            // 
            // lblFechaOperacion
            // 
            this.lblFechaOperacion.AutoSize = true;
            this.lblFechaOperacion.Location = new System.Drawing.Point(22, 269);
            this.lblFechaOperacion.Name = "lblFechaOperacion";
            this.lblFechaOperacion.Size = new System.Drawing.Size(89, 13);
            this.lblFechaOperacion.TabIndex = 50;
            this.lblFechaOperacion.Text = "Fecha Operación";
            // 
            // gbImporteRectificacion
            // 
            this.gbImporteRectificacion.Controls.Add(this.txtImpRecCuotaRecargoRectificado);
            this.gbImporteRectificacion.Controls.Add(this.lblImpRecCuotaRecargoRectificado);
            this.gbImporteRectificacion.Controls.Add(this.txtImpRecCuotaRectificada);
            this.gbImporteRectificacion.Controls.Add(this.lblImpRecCuotaRectificada);
            this.gbImporteRectificacion.Controls.Add(this.txtImpRecBaseRectificada);
            this.gbImporteRectificacion.Controls.Add(this.lblImpRecBaseRectificada);
            this.gbImporteRectificacion.Location = new System.Drawing.Point(13, 165);
            this.gbImporteRectificacion.Name = "gbImporteRectificacion";
            this.gbImporteRectificacion.Size = new System.Drawing.Size(411, 93);
            this.gbImporteRectificacion.TabIndex = 45;
            this.gbImporteRectificacion.TabStop = false;
            this.gbImporteRectificacion.Text = " Importe Rectificación ";
            // 
            // txtImpRecCuotaRecargoRectificado
            // 
            this.txtImpRecCuotaRecargoRectificado.Location = new System.Drawing.Point(233, 65);
            this.txtImpRecCuotaRecargoRectificado.Name = "txtImpRecCuotaRecargoRectificado";
            this.txtImpRecCuotaRecargoRectificado.ReadOnly = true;
            this.txtImpRecCuotaRecargoRectificado.Size = new System.Drawing.Size(167, 20);
            this.txtImpRecCuotaRecargoRectificado.TabIndex = 12;
            // 
            // lblImpRecCuotaRecargoRectificado
            // 
            this.lblImpRecCuotaRecargoRectificado.AutoSize = true;
            this.lblImpRecCuotaRecargoRectificado.Location = new System.Drawing.Point(9, 65);
            this.lblImpRecCuotaRecargoRectificado.Name = "lblImpRecCuotaRecargoRectificado";
            this.lblImpRecCuotaRecargoRectificado.Size = new System.Drawing.Size(136, 13);
            this.lblImpRecCuotaRecargoRectificado.TabIndex = 11;
            this.lblImpRecCuotaRecargoRectificado.Text = "Cuota Recargo Rectificado";
            // 
            // txtImpRecCuotaRectificada
            // 
            this.txtImpRecCuotaRectificada.Location = new System.Drawing.Point(233, 40);
            this.txtImpRecCuotaRectificada.Name = "txtImpRecCuotaRectificada";
            this.txtImpRecCuotaRectificada.ReadOnly = true;
            this.txtImpRecCuotaRectificada.Size = new System.Drawing.Size(167, 20);
            this.txtImpRecCuotaRectificada.TabIndex = 10;
            // 
            // lblImpRecCuotaRectificada
            // 
            this.lblImpRecCuotaRectificada.AutoSize = true;
            this.lblImpRecCuotaRectificada.Location = new System.Drawing.Point(9, 43);
            this.lblImpRecCuotaRectificada.Name = "lblImpRecCuotaRectificada";
            this.lblImpRecCuotaRectificada.Size = new System.Drawing.Size(92, 13);
            this.lblImpRecCuotaRectificada.TabIndex = 9;
            this.lblImpRecCuotaRectificada.Text = "Cuota Rectificada";
            // 
            // txtImpRecBaseRectificada
            // 
            this.txtImpRecBaseRectificada.Location = new System.Drawing.Point(233, 15);
            this.txtImpRecBaseRectificada.Name = "txtImpRecBaseRectificada";
            this.txtImpRecBaseRectificada.ReadOnly = true;
            this.txtImpRecBaseRectificada.Size = new System.Drawing.Size(167, 20);
            this.txtImpRecBaseRectificada.TabIndex = 8;
            // 
            // lblImpRecBaseRectificada
            // 
            this.lblImpRecBaseRectificada.AutoSize = true;
            this.lblImpRecBaseRectificada.Location = new System.Drawing.Point(9, 22);
            this.lblImpRecBaseRectificada.Name = "lblImpRecBaseRectificada";
            this.lblImpRecBaseRectificada.Size = new System.Drawing.Size(88, 13);
            this.lblImpRecBaseRectificada.TabIndex = 6;
            this.lblImpRecBaseRectificada.Text = "Base Rectificada";
            // 
            // gbFactRectificada
            // 
            this.gbFactRectificada.Controls.Add(this.txtRectificadaFechaExpedicionFacturaEmisor);
            this.gbFactRectificada.Controls.Add(this.lblRectificadaFechaExpedicionFacturaEmisor);
            this.gbFactRectificada.Controls.Add(this.txtlRectificadaNumSeriFacturaEmisor);
            this.gbFactRectificada.Controls.Add(this.lblRectificadaNumSeriFacturaEmisor);
            this.gbFactRectificada.Location = new System.Drawing.Point(13, 93);
            this.gbFactRectificada.Name = "gbFactRectificada";
            this.gbFactRectificada.Size = new System.Drawing.Size(411, 69);
            this.gbFactRectificada.TabIndex = 40;
            this.gbFactRectificada.TabStop = false;
            this.gbFactRectificada.Text = " Factura Rectificada ";
            // 
            // txtRectificadaFechaExpedicionFacturaEmisor
            // 
            this.txtRectificadaFechaExpedicionFacturaEmisor.Location = new System.Drawing.Point(233, 40);
            this.txtRectificadaFechaExpedicionFacturaEmisor.Name = "txtRectificadaFechaExpedicionFacturaEmisor";
            this.txtRectificadaFechaExpedicionFacturaEmisor.ReadOnly = true;
            this.txtRectificadaFechaExpedicionFacturaEmisor.Size = new System.Drawing.Size(167, 20);
            this.txtRectificadaFechaExpedicionFacturaEmisor.TabIndex = 10;
            // 
            // lblRectificadaFechaExpedicionFacturaEmisor
            // 
            this.lblRectificadaFechaExpedicionFacturaEmisor.AutoSize = true;
            this.lblRectificadaFechaExpedicionFacturaEmisor.Location = new System.Drawing.Point(9, 44);
            this.lblRectificadaFechaExpedicionFacturaEmisor.Name = "lblRectificadaFechaExpedicionFacturaEmisor";
            this.lblRectificadaFechaExpedicionFacturaEmisor.Size = new System.Drawing.Size(165, 13);
            this.lblRectificadaFechaExpedicionFacturaEmisor.TabIndex = 9;
            this.lblRectificadaFechaExpedicionFacturaEmisor.Text = "Fecha Expedición Factura Emisor";
            // 
            // txtlRectificadaNumSeriFacturaEmisor
            // 
            this.txtlRectificadaNumSeriFacturaEmisor.Location = new System.Drawing.Point(233, 16);
            this.txtlRectificadaNumSeriFacturaEmisor.Name = "txtlRectificadaNumSeriFacturaEmisor";
            this.txtlRectificadaNumSeriFacturaEmisor.ReadOnly = true;
            this.txtlRectificadaNumSeriFacturaEmisor.Size = new System.Drawing.Size(167, 20);
            this.txtlRectificadaNumSeriFacturaEmisor.TabIndex = 8;
            // 
            // lblRectificadaNumSeriFacturaEmisor
            // 
            this.lblRectificadaNumSeriFacturaEmisor.AutoSize = true;
            this.lblRectificadaNumSeriFacturaEmisor.Location = new System.Drawing.Point(9, 21);
            this.lblRectificadaNumSeriFacturaEmisor.Name = "lblRectificadaNumSeriFacturaEmisor";
            this.lblRectificadaNumSeriFacturaEmisor.Size = new System.Drawing.Size(144, 13);
            this.lblRectificadaNumSeriFacturaEmisor.TabIndex = 6;
            this.lblRectificadaNumSeriFacturaEmisor.Text = "Número Serie Factura Emisor";
            // 
            // txtTipoRectificativa
            // 
            this.txtTipoRectificativa.Location = new System.Drawing.Point(246, 68);
            this.txtTipoRectificativa.Name = "txtTipoRectificativa";
            this.txtTipoRectificativa.ReadOnly = true;
            this.txtTipoRectificativa.Size = new System.Drawing.Size(167, 20);
            this.txtTipoRectificativa.TabIndex = 30;
            // 
            // lblTipoRectificativa
            // 
            this.lblTipoRectificativa.AutoSize = true;
            this.lblTipoRectificativa.Location = new System.Drawing.Point(22, 71);
            this.lblTipoRectificativa.Name = "lblTipoRectificativa";
            this.lblTipoRectificativa.Size = new System.Drawing.Size(90, 13);
            this.lblTipoRectificativa.TabIndex = 25;
            this.lblTipoRectificativa.Text = "Tipo Rectificativa";
            // 
            // txtTipoFactura
            // 
            this.txtTipoFactura.Location = new System.Drawing.Point(246, 18);
            this.txtTipoFactura.Name = "txtTipoFactura";
            this.txtTipoFactura.ReadOnly = true;
            this.txtTipoFactura.Size = new System.Drawing.Size(167, 20);
            this.txtTipoFactura.TabIndex = 10;
            // 
            // lblTipoFactura
            // 
            this.lblTipoFactura.AutoSize = true;
            this.lblTipoFactura.Location = new System.Drawing.Point(22, 22);
            this.lblTipoFactura.Name = "lblTipoFactura";
            this.lblTipoFactura.Size = new System.Drawing.Size(67, 13);
            this.lblTipoFactura.TabIndex = 5;
            this.lblTipoFactura.Text = "Tipo Factura";
            // 
            // txtNumSerieFacturaEmisorResumenFin
            // 
            this.txtNumSerieFacturaEmisorResumenFin.Location = new System.Drawing.Point(709, 240);
            this.txtNumSerieFacturaEmisorResumenFin.Name = "txtNumSerieFacturaEmisorResumenFin";
            this.txtNumSerieFacturaEmisorResumenFin.ReadOnly = true;
            this.txtNumSerieFacturaEmisorResumenFin.Size = new System.Drawing.Size(167, 20);
            this.txtNumSerieFacturaEmisorResumenFin.TabIndex = 105;
            // 
            // lblNumSerieFacturaEmisorResumenFin
            // 
            this.lblNumSerieFacturaEmisorResumenFin.AutoSize = true;
            this.lblNumSerieFacturaEmisorResumenFin.Location = new System.Drawing.Point(453, 240);
            this.lblNumSerieFacturaEmisorResumenFin.Name = "lblNumSerieFacturaEmisorResumenFin";
            this.lblNumSerieFacturaEmisorResumenFin.Size = new System.Drawing.Size(209, 13);
            this.lblNumSerieFacturaEmisorResumenFin.TabIndex = 100;
            this.lblNumSerieFacturaEmisorResumenFin.Text = "Número Serie Factura Emisor Resumen Fin";
            // 
            // tabPageDesgloseFactura
            // 
            this.tabPageDesgloseFactura.Controls.Add(this.gbDF_NoSujeta);
            this.tabPageDesgloseFactura.Controls.Add(this.gbDF_Sujeta);
            this.tabPageDesgloseFactura.Location = new System.Drawing.Point(4, 22);
            this.tabPageDesgloseFactura.Name = "tabPageDesgloseFactura";
            this.tabPageDesgloseFactura.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDesgloseFactura.Size = new System.Drawing.Size(903, 471);
            this.tabPageDesgloseFactura.TabIndex = 1;
            this.tabPageDesgloseFactura.Text = "Desglose Factura";
            this.tabPageDesgloseFactura.UseVisualStyleBackColor = true;
            // 
            // gbDF_NoSujeta
            // 
            this.gbDF_NoSujeta.Controls.Add(this.txtDF_NS_ImporteTAIReglasLocalizacion);
            this.gbDF_NoSujeta.Controls.Add(this.lblDF_NS_ImporteTAIReglasLocalizacion);
            this.gbDF_NoSujeta.Controls.Add(this.txtDF_NS_ImporteArticulos7_14_Otros);
            this.gbDF_NoSujeta.Controls.Add(this.lblDF_NS_ImporteArticulos7_14_Otros);
            this.gbDF_NoSujeta.Location = new System.Drawing.Point(18, 394);
            this.gbDF_NoSujeta.Name = "gbDF_NoSujeta";
            this.gbDF_NoSujeta.Size = new System.Drawing.Size(815, 71);
            this.gbDF_NoSujeta.TabIndex = 1;
            this.gbDF_NoSujeta.TabStop = false;
            this.gbDF_NoSujeta.Text = " No Sujeta ";
            // 
            // txtDF_NS_ImporteTAIReglasLocalizacion
            // 
            this.txtDF_NS_ImporteTAIReglasLocalizacion.Location = new System.Drawing.Point(209, 41);
            this.txtDF_NS_ImporteTAIReglasLocalizacion.Name = "txtDF_NS_ImporteTAIReglasLocalizacion";
            this.txtDF_NS_ImporteTAIReglasLocalizacion.ReadOnly = true;
            this.txtDF_NS_ImporteTAIReglasLocalizacion.Size = new System.Drawing.Size(167, 20);
            this.txtDF_NS_ImporteTAIReglasLocalizacion.TabIndex = 12;
            // 
            // lblDF_NS_ImporteTAIReglasLocalizacion
            // 
            this.lblDF_NS_ImporteTAIReglasLocalizacion.AutoSize = true;
            this.lblDF_NS_ImporteTAIReglasLocalizacion.Location = new System.Drawing.Point(25, 46);
            this.lblDF_NS_ImporteTAIReglasLocalizacion.Name = "lblDF_NS_ImporteTAIReglasLocalizacion";
            this.lblDF_NS_ImporteTAIReglasLocalizacion.Size = new System.Drawing.Size(160, 13);
            this.lblDF_NS_ImporteTAIReglasLocalizacion.TabIndex = 11;
            this.lblDF_NS_ImporteTAIReglasLocalizacion.Text = "Importe TAI Reglas Localización";
            // 
            // txtDF_NS_ImporteArticulos7_14_Otros
            // 
            this.txtDF_NS_ImporteArticulos7_14_Otros.Location = new System.Drawing.Point(209, 17);
            this.txtDF_NS_ImporteArticulos7_14_Otros.Name = "txtDF_NS_ImporteArticulos7_14_Otros";
            this.txtDF_NS_ImporteArticulos7_14_Otros.ReadOnly = true;
            this.txtDF_NS_ImporteArticulos7_14_Otros.Size = new System.Drawing.Size(167, 20);
            this.txtDF_NS_ImporteArticulos7_14_Otros.TabIndex = 10;
            // 
            // lblDF_NS_ImporteArticulos7_14_Otros
            // 
            this.lblDF_NS_ImporteArticulos7_14_Otros.AutoSize = true;
            this.lblDF_NS_ImporteArticulos7_14_Otros.Location = new System.Drawing.Point(25, 22);
            this.lblDF_NS_ImporteArticulos7_14_Otros.Name = "lblDF_NS_ImporteArticulos7_14_Otros";
            this.lblDF_NS_ImporteArticulos7_14_Otros.Size = new System.Drawing.Size(164, 13);
            this.lblDF_NS_ImporteArticulos7_14_Otros.TabIndex = 9;
            this.lblDF_NS_ImporteArticulos7_14_Otros.Text = "Importe Por Artículos 7_14_Otros";
            // 
            // gbDF_Sujeta
            // 
            this.gbDF_Sujeta.Controls.Add(this.gbDF_SujetaNoExenta);
            this.gbDF_Sujeta.Controls.Add(this.gbDF_SujetaExenta);
            this.gbDF_Sujeta.Location = new System.Drawing.Point(19, 10);
            this.gbDF_Sujeta.Name = "gbDF_Sujeta";
            this.gbDF_Sujeta.Size = new System.Drawing.Size(815, 377);
            this.gbDF_Sujeta.TabIndex = 0;
            this.gbDF_Sujeta.TabStop = false;
            this.gbDF_Sujeta.Text = " Sujeta ";
            // 
            // gbDF_SujetaNoExenta
            // 
            this.gbDF_SujetaNoExenta.Controls.Add(this.gbDF_SNE_DetalleIVA);
            this.gbDF_SujetaNoExenta.Controls.Add(this.txtDF_SNE_TipoNoExenta);
            this.gbDF_SujetaNoExenta.Controls.Add(this.lblDF_SNE_TipoNoExenta);
            this.gbDF_SujetaNoExenta.Location = new System.Drawing.Point(20, 17);
            this.gbDF_SujetaNoExenta.Name = "gbDF_SujetaNoExenta";
            this.gbDF_SujetaNoExenta.Size = new System.Drawing.Size(789, 225);
            this.gbDF_SujetaNoExenta.TabIndex = 1;
            this.gbDF_SujetaNoExenta.TabStop = false;
            this.gbDF_SujetaNoExenta.Text = " No Exenta ";
            // 
            // gbDF_SNE_DetalleIVA
            // 
            this.gbDF_SNE_DetalleIVA.Controls.Add(this.lblDF_SNE_NoExisteDetalleIVA);
            this.gbDF_SNE_DetalleIVA.Controls.Add(this.dgDF_SNE_DetalleIVA);
            this.gbDF_SNE_DetalleIVA.Location = new System.Drawing.Point(6, 45);
            this.gbDF_SNE_DetalleIVA.Name = "gbDF_SNE_DetalleIVA";
            this.gbDF_SNE_DetalleIVA.Size = new System.Drawing.Size(777, 174);
            this.gbDF_SNE_DetalleIVA.TabIndex = 11;
            this.gbDF_SNE_DetalleIVA.TabStop = false;
            this.gbDF_SNE_DetalleIVA.Text = "Detalle IVA";
            // 
            // lblDF_SNE_NoExisteDetalleIVA
            // 
            this.lblDF_SNE_NoExisteDetalleIVA.AutoSize = true;
            this.lblDF_SNE_NoExisteDetalleIVA.Location = new System.Drawing.Point(20, 24);
            this.lblDF_SNE_NoExisteDetalleIVA.Name = "lblDF_SNE_NoExisteDetalleIVA";
            this.lblDF_SNE_NoExisteDetalleIVA.Size = new System.Drawing.Size(159, 13);
            this.lblDF_SNE_NoExisteDetalleIVA.TabIndex = 1;
            this.lblDF_SNE_NoExisteDetalleIVA.Text = "No hay informado detalle de IVA";
            this.lblDF_SNE_NoExisteDetalleIVA.Visible = false;
            // 
            // dgDF_SNE_DetalleIVA
            // 
            this.dgDF_SNE_DetalleIVA.AddUltimaFilaSiNoHayDisponile = false;
            this.dgDF_SNE_DetalleIVA.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDF_SNE_DetalleIVA.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDF_SNE_DetalleIVA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDF_SNE_DetalleIVA.ComboValores = null;
            this.dgDF_SNE_DetalleIVA.ContextMenuStripGrid = null;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDF_SNE_DetalleIVA.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgDF_SNE_DetalleIVA.DSDatos = null;
            this.dgDF_SNE_DetalleIVA.Location = new System.Drawing.Point(23, 19);
            this.dgDF_SNE_DetalleIVA.Name = "dgDF_SNE_DetalleIVA";
            this.dgDF_SNE_DetalleIVA.NombreTabla = "";
            this.dgDF_SNE_DetalleIVA.RowHeaderInitWidth = 41;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDF_SNE_DetalleIVA.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgDF_SNE_DetalleIVA.RowNumber = false;
            this.dgDF_SNE_DetalleIVA.Size = new System.Drawing.Size(748, 149);
            this.dgDF_SNE_DetalleIVA.TabIndex = 0;
            this.dgDF_SNE_DetalleIVA.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgDF_SNE_DetalleIVA_DataBindingComplete);
            // 
            // txtDF_SNE_TipoNoExenta
            // 
            this.txtDF_SNE_TipoNoExenta.Location = new System.Drawing.Point(130, 19);
            this.txtDF_SNE_TipoNoExenta.Name = "txtDF_SNE_TipoNoExenta";
            this.txtDF_SNE_TipoNoExenta.ReadOnly = true;
            this.txtDF_SNE_TipoNoExenta.Size = new System.Drawing.Size(200, 20);
            this.txtDF_SNE_TipoNoExenta.TabIndex = 10;
            // 
            // lblDF_SNE_TipoNoExenta
            // 
            this.lblDF_SNE_TipoNoExenta.AutoSize = true;
            this.lblDF_SNE_TipoNoExenta.Location = new System.Drawing.Point(23, 24);
            this.lblDF_SNE_TipoNoExenta.Name = "lblDF_SNE_TipoNoExenta";
            this.lblDF_SNE_TipoNoExenta.Size = new System.Drawing.Size(81, 13);
            this.lblDF_SNE_TipoNoExenta.TabIndex = 9;
            this.lblDF_SNE_TipoNoExenta.Text = "Tipo No Exenta";
            // 
            // gbDF_SujetaExenta
            // 
            this.gbDF_SujetaExenta.Controls.Add(this.lblDF_SE_NoExisteDetalleExenta);
            this.gbDF_SujetaExenta.Controls.Add(this.dgDF_SE_DetalleExenta);
            this.gbDF_SujetaExenta.Location = new System.Drawing.Point(20, 248);
            this.gbDF_SujetaExenta.Name = "gbDF_SujetaExenta";
            this.gbDF_SujetaExenta.Size = new System.Drawing.Size(789, 123);
            this.gbDF_SujetaExenta.TabIndex = 0;
            this.gbDF_SujetaExenta.TabStop = false;
            this.gbDF_SujetaExenta.Text = " Detalle Exenta ";
            // 
            // lblDF_SE_NoExisteDetalleExenta
            // 
            this.lblDF_SE_NoExisteDetalleExenta.AutoSize = true;
            this.lblDF_SE_NoExisteDetalleExenta.Location = new System.Drawing.Point(26, 24);
            this.lblDF_SE_NoExisteDetalleExenta.Name = "lblDF_SE_NoExisteDetalleExenta";
            this.lblDF_SE_NoExisteDetalleExenta.Size = new System.Drawing.Size(175, 13);
            this.lblDF_SE_NoExisteDetalleExenta.TabIndex = 14;
            this.lblDF_SE_NoExisteDetalleExenta.Text = "No hay informado detalle de Exenta";
            this.lblDF_SE_NoExisteDetalleExenta.Visible = false;
            // 
            // dgDF_SE_DetalleExenta
            // 
            this.dgDF_SE_DetalleExenta.AddUltimaFilaSiNoHayDisponile = false;
            this.dgDF_SE_DetalleExenta.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDF_SE_DetalleExenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgDF_SE_DetalleExenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDF_SE_DetalleExenta.ComboValores = null;
            this.dgDF_SE_DetalleExenta.ContextMenuStripGrid = null;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDF_SE_DetalleExenta.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgDF_SE_DetalleExenta.DSDatos = null;
            this.dgDF_SE_DetalleExenta.Location = new System.Drawing.Point(29, 18);
            this.dgDF_SE_DetalleExenta.Name = "dgDF_SE_DetalleExenta";
            this.dgDF_SE_DetalleExenta.NombreTabla = "";
            this.dgDF_SE_DetalleExenta.RowHeaderInitWidth = 41;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDF_SE_DetalleExenta.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgDF_SE_DetalleExenta.RowNumber = false;
            this.dgDF_SE_DetalleExenta.Size = new System.Drawing.Size(445, 97);
            this.dgDF_SE_DetalleExenta.TabIndex = 15;
            this.dgDF_SE_DetalleExenta.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgDF_SE_DetalleExenta_DataBindingComplete);
            // 
            // tabPagePrestacionServicios
            // 
            this.tabPagePrestacionServicios.Controls.Add(this.gbDPS_NoSujeta);
            this.tabPagePrestacionServicios.Controls.Add(this.gbDPS_Sujeta);
            this.tabPagePrestacionServicios.Location = new System.Drawing.Point(4, 22);
            this.tabPagePrestacionServicios.Name = "tabPagePrestacionServicios";
            this.tabPagePrestacionServicios.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePrestacionServicios.Size = new System.Drawing.Size(903, 471);
            this.tabPagePrestacionServicios.TabIndex = 2;
            this.tabPagePrestacionServicios.Text = "Desglose Prestación Servicios";
            this.tabPagePrestacionServicios.UseVisualStyleBackColor = true;
            // 
            // gbDPS_NoSujeta
            // 
            this.gbDPS_NoSujeta.Controls.Add(this.txtDPS_NS_ImporteTAIReglasLocalizacion);
            this.gbDPS_NoSujeta.Controls.Add(this.lblDPS_NS_ImporteTAIReglasLocalizacion);
            this.gbDPS_NoSujeta.Controls.Add(this.txtDPS_NS_ImporteArticulos7_14_Otros);
            this.gbDPS_NoSujeta.Controls.Add(this.lblDPS_NS_ImporteArticulos7_14_Otros);
            this.gbDPS_NoSujeta.Location = new System.Drawing.Point(18, 394);
            this.gbDPS_NoSujeta.Name = "gbDPS_NoSujeta";
            this.gbDPS_NoSujeta.Size = new System.Drawing.Size(815, 71);
            this.gbDPS_NoSujeta.TabIndex = 3;
            this.gbDPS_NoSujeta.TabStop = false;
            this.gbDPS_NoSujeta.Text = " No Sujeta ";
            // 
            // txtDPS_NS_ImporteTAIReglasLocalizacion
            // 
            this.txtDPS_NS_ImporteTAIReglasLocalizacion.Location = new System.Drawing.Point(209, 41);
            this.txtDPS_NS_ImporteTAIReglasLocalizacion.Name = "txtDPS_NS_ImporteTAIReglasLocalizacion";
            this.txtDPS_NS_ImporteTAIReglasLocalizacion.ReadOnly = true;
            this.txtDPS_NS_ImporteTAIReglasLocalizacion.Size = new System.Drawing.Size(167, 20);
            this.txtDPS_NS_ImporteTAIReglasLocalizacion.TabIndex = 12;
            // 
            // lblDPS_NS_ImporteTAIReglasLocalizacion
            // 
            this.lblDPS_NS_ImporteTAIReglasLocalizacion.AutoSize = true;
            this.lblDPS_NS_ImporteTAIReglasLocalizacion.Location = new System.Drawing.Point(25, 46);
            this.lblDPS_NS_ImporteTAIReglasLocalizacion.Name = "lblDPS_NS_ImporteTAIReglasLocalizacion";
            this.lblDPS_NS_ImporteTAIReglasLocalizacion.Size = new System.Drawing.Size(160, 13);
            this.lblDPS_NS_ImporteTAIReglasLocalizacion.TabIndex = 11;
            this.lblDPS_NS_ImporteTAIReglasLocalizacion.Text = "Importe TAI Reglas Localización";
            // 
            // txtDPS_NS_ImporteArticulos7_14_Otros
            // 
            this.txtDPS_NS_ImporteArticulos7_14_Otros.Location = new System.Drawing.Point(209, 17);
            this.txtDPS_NS_ImporteArticulos7_14_Otros.Name = "txtDPS_NS_ImporteArticulos7_14_Otros";
            this.txtDPS_NS_ImporteArticulos7_14_Otros.ReadOnly = true;
            this.txtDPS_NS_ImporteArticulos7_14_Otros.Size = new System.Drawing.Size(167, 20);
            this.txtDPS_NS_ImporteArticulos7_14_Otros.TabIndex = 10;
            // 
            // lblDPS_NS_ImporteArticulos7_14_Otros
            // 
            this.lblDPS_NS_ImporteArticulos7_14_Otros.AutoSize = true;
            this.lblDPS_NS_ImporteArticulos7_14_Otros.Location = new System.Drawing.Point(25, 22);
            this.lblDPS_NS_ImporteArticulos7_14_Otros.Name = "lblDPS_NS_ImporteArticulos7_14_Otros";
            this.lblDPS_NS_ImporteArticulos7_14_Otros.Size = new System.Drawing.Size(164, 13);
            this.lblDPS_NS_ImporteArticulos7_14_Otros.TabIndex = 9;
            this.lblDPS_NS_ImporteArticulos7_14_Otros.Text = "Importe Por Artículos 7_14_Otros";
            // 
            // gbDPS_Sujeta
            // 
            this.gbDPS_Sujeta.Controls.Add(this.gbDPS_SujetaNoExenta);
            this.gbDPS_Sujeta.Controls.Add(this.gbDPS_SujetaExenta);
            this.gbDPS_Sujeta.Location = new System.Drawing.Point(19, 10);
            this.gbDPS_Sujeta.Name = "gbDPS_Sujeta";
            this.gbDPS_Sujeta.Size = new System.Drawing.Size(815, 377);
            this.gbDPS_Sujeta.TabIndex = 2;
            this.gbDPS_Sujeta.TabStop = false;
            this.gbDPS_Sujeta.Text = " Sujeta ";
            // 
            // gbDPS_SujetaNoExenta
            // 
            this.gbDPS_SujetaNoExenta.Controls.Add(this.gbDPS_SNE_DetalleIVA);
            this.gbDPS_SujetaNoExenta.Controls.Add(this.txtDPS_SNE_TipoNoExenta);
            this.gbDPS_SujetaNoExenta.Controls.Add(this.lblDPS_SNE_TipoNoExenta);
            this.gbDPS_SujetaNoExenta.Location = new System.Drawing.Point(20, 17);
            this.gbDPS_SujetaNoExenta.Name = "gbDPS_SujetaNoExenta";
            this.gbDPS_SujetaNoExenta.Size = new System.Drawing.Size(789, 225);
            this.gbDPS_SujetaNoExenta.TabIndex = 1;
            this.gbDPS_SujetaNoExenta.TabStop = false;
            this.gbDPS_SujetaNoExenta.Text = " No Exenta ";
            // 
            // gbDPS_SNE_DetalleIVA
            // 
            this.gbDPS_SNE_DetalleIVA.Controls.Add(this.lblDPS_SNE_NoExisteDetalleIVA);
            this.gbDPS_SNE_DetalleIVA.Controls.Add(this.dgDPS_SNE_DetalleIVA);
            this.gbDPS_SNE_DetalleIVA.Location = new System.Drawing.Point(6, 45);
            this.gbDPS_SNE_DetalleIVA.Name = "gbDPS_SNE_DetalleIVA";
            this.gbDPS_SNE_DetalleIVA.Size = new System.Drawing.Size(777, 174);
            this.gbDPS_SNE_DetalleIVA.TabIndex = 11;
            this.gbDPS_SNE_DetalleIVA.TabStop = false;
            this.gbDPS_SNE_DetalleIVA.Text = "Detalle IVA";
            // 
            // lblDPS_SNE_NoExisteDetalleIVA
            // 
            this.lblDPS_SNE_NoExisteDetalleIVA.AutoSize = true;
            this.lblDPS_SNE_NoExisteDetalleIVA.Location = new System.Drawing.Point(20, 24);
            this.lblDPS_SNE_NoExisteDetalleIVA.Name = "lblDPS_SNE_NoExisteDetalleIVA";
            this.lblDPS_SNE_NoExisteDetalleIVA.Size = new System.Drawing.Size(159, 13);
            this.lblDPS_SNE_NoExisteDetalleIVA.TabIndex = 1;
            this.lblDPS_SNE_NoExisteDetalleIVA.Text = "No hay informado detalle de IVA";
            this.lblDPS_SNE_NoExisteDetalleIVA.Visible = false;
            // 
            // dgDPS_SNE_DetalleIVA
            // 
            this.dgDPS_SNE_DetalleIVA.AddUltimaFilaSiNoHayDisponile = false;
            this.dgDPS_SNE_DetalleIVA.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDPS_SNE_DetalleIVA.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgDPS_SNE_DetalleIVA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDPS_SNE_DetalleIVA.ComboValores = null;
            this.dgDPS_SNE_DetalleIVA.ContextMenuStripGrid = null;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDPS_SNE_DetalleIVA.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgDPS_SNE_DetalleIVA.DSDatos = null;
            this.dgDPS_SNE_DetalleIVA.Location = new System.Drawing.Point(23, 19);
            this.dgDPS_SNE_DetalleIVA.Name = "dgDPS_SNE_DetalleIVA";
            this.dgDPS_SNE_DetalleIVA.NombreTabla = "";
            this.dgDPS_SNE_DetalleIVA.RowHeaderInitWidth = 41;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDPS_SNE_DetalleIVA.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgDPS_SNE_DetalleIVA.RowNumber = false;
            this.dgDPS_SNE_DetalleIVA.Size = new System.Drawing.Size(748, 149);
            this.dgDPS_SNE_DetalleIVA.TabIndex = 0;
            this.dgDPS_SNE_DetalleIVA.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgDPS_SNE_DetalleIVA_DataBindingComplete);
            // 
            // txtDPS_SNE_TipoNoExenta
            // 
            this.txtDPS_SNE_TipoNoExenta.Location = new System.Drawing.Point(130, 19);
            this.txtDPS_SNE_TipoNoExenta.Name = "txtDPS_SNE_TipoNoExenta";
            this.txtDPS_SNE_TipoNoExenta.ReadOnly = true;
            this.txtDPS_SNE_TipoNoExenta.Size = new System.Drawing.Size(200, 20);
            this.txtDPS_SNE_TipoNoExenta.TabIndex = 10;
            // 
            // lblDPS_SNE_TipoNoExenta
            // 
            this.lblDPS_SNE_TipoNoExenta.AutoSize = true;
            this.lblDPS_SNE_TipoNoExenta.Location = new System.Drawing.Point(23, 24);
            this.lblDPS_SNE_TipoNoExenta.Name = "lblDPS_SNE_TipoNoExenta";
            this.lblDPS_SNE_TipoNoExenta.Size = new System.Drawing.Size(81, 13);
            this.lblDPS_SNE_TipoNoExenta.TabIndex = 9;
            this.lblDPS_SNE_TipoNoExenta.Text = "Tipo No Exenta";
            // 
            // gbDPS_SujetaExenta
            // 
            this.gbDPS_SujetaExenta.Controls.Add(this.lblDPS_SE_NoExisteDetalleExenta);
            this.gbDPS_SujetaExenta.Controls.Add(this.dgDPS_SE_DetalleExenta);
            this.gbDPS_SujetaExenta.Location = new System.Drawing.Point(20, 248);
            this.gbDPS_SujetaExenta.Name = "gbDPS_SujetaExenta";
            this.gbDPS_SujetaExenta.Size = new System.Drawing.Size(789, 123);
            this.gbDPS_SujetaExenta.TabIndex = 0;
            this.gbDPS_SujetaExenta.TabStop = false;
            this.gbDPS_SujetaExenta.Text = " Detalle Exenta ";
            // 
            // lblDPS_SE_NoExisteDetalleExenta
            // 
            this.lblDPS_SE_NoExisteDetalleExenta.AutoSize = true;
            this.lblDPS_SE_NoExisteDetalleExenta.Location = new System.Drawing.Point(26, 24);
            this.lblDPS_SE_NoExisteDetalleExenta.Name = "lblDPS_SE_NoExisteDetalleExenta";
            this.lblDPS_SE_NoExisteDetalleExenta.Size = new System.Drawing.Size(175, 13);
            this.lblDPS_SE_NoExisteDetalleExenta.TabIndex = 17;
            this.lblDPS_SE_NoExisteDetalleExenta.Text = "No hay informado detalle de Exenta";
            this.lblDPS_SE_NoExisteDetalleExenta.Visible = false;
            // 
            // dgDPS_SE_DetalleExenta
            // 
            this.dgDPS_SE_DetalleExenta.AddUltimaFilaSiNoHayDisponile = false;
            this.dgDPS_SE_DetalleExenta.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDPS_SE_DetalleExenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgDPS_SE_DetalleExenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDPS_SE_DetalleExenta.ComboValores = null;
            this.dgDPS_SE_DetalleExenta.ContextMenuStripGrid = null;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDPS_SE_DetalleExenta.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgDPS_SE_DetalleExenta.DSDatos = null;
            this.dgDPS_SE_DetalleExenta.Location = new System.Drawing.Point(29, 18);
            this.dgDPS_SE_DetalleExenta.Name = "dgDPS_SE_DetalleExenta";
            this.dgDPS_SE_DetalleExenta.NombreTabla = "";
            this.dgDPS_SE_DetalleExenta.RowHeaderInitWidth = 41;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDPS_SE_DetalleExenta.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgDPS_SE_DetalleExenta.RowNumber = false;
            this.dgDPS_SE_DetalleExenta.Size = new System.Drawing.Size(445, 97);
            this.dgDPS_SE_DetalleExenta.TabIndex = 16;
            this.dgDPS_SE_DetalleExenta.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgDPS_SE_DetalleExenta_DataBindingComplete);
            // 
            // tabPageEntrega
            // 
            this.tabPageEntrega.Controls.Add(this.gbDE_NoSujeta);
            this.tabPageEntrega.Controls.Add(this.gbDE_Sujeta);
            this.tabPageEntrega.Location = new System.Drawing.Point(4, 22);
            this.tabPageEntrega.Name = "tabPageEntrega";
            this.tabPageEntrega.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEntrega.Size = new System.Drawing.Size(903, 471);
            this.tabPageEntrega.TabIndex = 3;
            this.tabPageEntrega.Text = "Desglose Entrega";
            this.tabPageEntrega.UseVisualStyleBackColor = true;
            // 
            // gbDE_NoSujeta
            // 
            this.gbDE_NoSujeta.Controls.Add(this.txtDE_NS_ImporteTAIReglasLocalizacion);
            this.gbDE_NoSujeta.Controls.Add(this.lblDE_NS_ImporteTAIReglasLocalizacion);
            this.gbDE_NoSujeta.Controls.Add(this.txtDE_NS_ImporteArticulos7_14_Otros);
            this.gbDE_NoSujeta.Controls.Add(this.lblDE_NS_ImporteArticulos7_14_Otros);
            this.gbDE_NoSujeta.Location = new System.Drawing.Point(18, 394);
            this.gbDE_NoSujeta.Name = "gbDE_NoSujeta";
            this.gbDE_NoSujeta.Size = new System.Drawing.Size(815, 71);
            this.gbDE_NoSujeta.TabIndex = 5;
            this.gbDE_NoSujeta.TabStop = false;
            this.gbDE_NoSujeta.Text = " No Sujeta ";
            // 
            // txtDE_NS_ImporteTAIReglasLocalizacion
            // 
            this.txtDE_NS_ImporteTAIReglasLocalizacion.Location = new System.Drawing.Point(209, 41);
            this.txtDE_NS_ImporteTAIReglasLocalizacion.Name = "txtDE_NS_ImporteTAIReglasLocalizacion";
            this.txtDE_NS_ImporteTAIReglasLocalizacion.ReadOnly = true;
            this.txtDE_NS_ImporteTAIReglasLocalizacion.Size = new System.Drawing.Size(167, 20);
            this.txtDE_NS_ImporteTAIReglasLocalizacion.TabIndex = 12;
            // 
            // lblDE_NS_ImporteTAIReglasLocalizacion
            // 
            this.lblDE_NS_ImporteTAIReglasLocalizacion.AutoSize = true;
            this.lblDE_NS_ImporteTAIReglasLocalizacion.Location = new System.Drawing.Point(25, 46);
            this.lblDE_NS_ImporteTAIReglasLocalizacion.Name = "lblDE_NS_ImporteTAIReglasLocalizacion";
            this.lblDE_NS_ImporteTAIReglasLocalizacion.Size = new System.Drawing.Size(160, 13);
            this.lblDE_NS_ImporteTAIReglasLocalizacion.TabIndex = 11;
            this.lblDE_NS_ImporteTAIReglasLocalizacion.Text = "Importe TAI Reglas Localización";
            // 
            // txtDE_NS_ImporteArticulos7_14_Otros
            // 
            this.txtDE_NS_ImporteArticulos7_14_Otros.Location = new System.Drawing.Point(209, 17);
            this.txtDE_NS_ImporteArticulos7_14_Otros.Name = "txtDE_NS_ImporteArticulos7_14_Otros";
            this.txtDE_NS_ImporteArticulos7_14_Otros.ReadOnly = true;
            this.txtDE_NS_ImporteArticulos7_14_Otros.Size = new System.Drawing.Size(167, 20);
            this.txtDE_NS_ImporteArticulos7_14_Otros.TabIndex = 10;
            // 
            // lblDE_NS_ImporteArticulos7_14_Otros
            // 
            this.lblDE_NS_ImporteArticulos7_14_Otros.AutoSize = true;
            this.lblDE_NS_ImporteArticulos7_14_Otros.Location = new System.Drawing.Point(25, 22);
            this.lblDE_NS_ImporteArticulos7_14_Otros.Name = "lblDE_NS_ImporteArticulos7_14_Otros";
            this.lblDE_NS_ImporteArticulos7_14_Otros.Size = new System.Drawing.Size(164, 13);
            this.lblDE_NS_ImporteArticulos7_14_Otros.TabIndex = 9;
            this.lblDE_NS_ImporteArticulos7_14_Otros.Text = "Importe Por Artículos 7_14_Otros";
            // 
            // gbDE_Sujeta
            // 
            this.gbDE_Sujeta.Controls.Add(this.gbDE_SujetaNoExenta);
            this.gbDE_Sujeta.Controls.Add(this.gbDE_SujetaExenta);
            this.gbDE_Sujeta.Location = new System.Drawing.Point(19, 10);
            this.gbDE_Sujeta.Name = "gbDE_Sujeta";
            this.gbDE_Sujeta.Size = new System.Drawing.Size(815, 377);
            this.gbDE_Sujeta.TabIndex = 4;
            this.gbDE_Sujeta.TabStop = false;
            this.gbDE_Sujeta.Text = " Sujeta ";
            // 
            // gbDE_SujetaNoExenta
            // 
            this.gbDE_SujetaNoExenta.Controls.Add(this.gbDE_SNE_DetalleIVA);
            this.gbDE_SujetaNoExenta.Controls.Add(this.txtDE_SNE_TipoNoExenta);
            this.gbDE_SujetaNoExenta.Controls.Add(this.lblDE_SNE_TipoNoExenta);
            this.gbDE_SujetaNoExenta.Location = new System.Drawing.Point(20, 17);
            this.gbDE_SujetaNoExenta.Name = "gbDE_SujetaNoExenta";
            this.gbDE_SujetaNoExenta.Size = new System.Drawing.Size(789, 225);
            this.gbDE_SujetaNoExenta.TabIndex = 1;
            this.gbDE_SujetaNoExenta.TabStop = false;
            this.gbDE_SujetaNoExenta.Text = " No Exenta ";
            // 
            // gbDE_SNE_DetalleIVA
            // 
            this.gbDE_SNE_DetalleIVA.Controls.Add(this.lblDE_SNE_NoExisteDetalleIVA);
            this.gbDE_SNE_DetalleIVA.Controls.Add(this.dgDE_SNE_DetalleIVA);
            this.gbDE_SNE_DetalleIVA.Location = new System.Drawing.Point(6, 45);
            this.gbDE_SNE_DetalleIVA.Name = "gbDE_SNE_DetalleIVA";
            this.gbDE_SNE_DetalleIVA.Size = new System.Drawing.Size(777, 174);
            this.gbDE_SNE_DetalleIVA.TabIndex = 11;
            this.gbDE_SNE_DetalleIVA.TabStop = false;
            this.gbDE_SNE_DetalleIVA.Text = "Detalle IVA";
            // 
            // lblDE_SNE_NoExisteDetalleIVA
            // 
            this.lblDE_SNE_NoExisteDetalleIVA.AutoSize = true;
            this.lblDE_SNE_NoExisteDetalleIVA.Location = new System.Drawing.Point(20, 24);
            this.lblDE_SNE_NoExisteDetalleIVA.Name = "lblDE_SNE_NoExisteDetalleIVA";
            this.lblDE_SNE_NoExisteDetalleIVA.Size = new System.Drawing.Size(159, 13);
            this.lblDE_SNE_NoExisteDetalleIVA.TabIndex = 1;
            this.lblDE_SNE_NoExisteDetalleIVA.Text = "No hay informado detalle de IVA";
            this.lblDE_SNE_NoExisteDetalleIVA.Visible = false;
            // 
            // dgDE_SNE_DetalleIVA
            // 
            this.dgDE_SNE_DetalleIVA.AddUltimaFilaSiNoHayDisponile = false;
            this.dgDE_SNE_DetalleIVA.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDE_SNE_DetalleIVA.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgDE_SNE_DetalleIVA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDE_SNE_DetalleIVA.ComboValores = null;
            this.dgDE_SNE_DetalleIVA.ContextMenuStripGrid = null;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDE_SNE_DetalleIVA.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgDE_SNE_DetalleIVA.DSDatos = null;
            this.dgDE_SNE_DetalleIVA.Location = new System.Drawing.Point(23, 19);
            this.dgDE_SNE_DetalleIVA.Name = "dgDE_SNE_DetalleIVA";
            this.dgDE_SNE_DetalleIVA.NombreTabla = "";
            this.dgDE_SNE_DetalleIVA.RowHeaderInitWidth = 41;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDE_SNE_DetalleIVA.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgDE_SNE_DetalleIVA.RowNumber = false;
            this.dgDE_SNE_DetalleIVA.Size = new System.Drawing.Size(748, 149);
            this.dgDE_SNE_DetalleIVA.TabIndex = 0;
            this.dgDE_SNE_DetalleIVA.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgDE_SNE_DetalleIVA_DataBindingComplete);
            // 
            // txtDE_SNE_TipoNoExenta
            // 
            this.txtDE_SNE_TipoNoExenta.Location = new System.Drawing.Point(130, 19);
            this.txtDE_SNE_TipoNoExenta.Name = "txtDE_SNE_TipoNoExenta";
            this.txtDE_SNE_TipoNoExenta.ReadOnly = true;
            this.txtDE_SNE_TipoNoExenta.Size = new System.Drawing.Size(200, 20);
            this.txtDE_SNE_TipoNoExenta.TabIndex = 10;
            // 
            // lblDE_SNE_TipoNoExenta
            // 
            this.lblDE_SNE_TipoNoExenta.AutoSize = true;
            this.lblDE_SNE_TipoNoExenta.Location = new System.Drawing.Point(23, 24);
            this.lblDE_SNE_TipoNoExenta.Name = "lblDE_SNE_TipoNoExenta";
            this.lblDE_SNE_TipoNoExenta.Size = new System.Drawing.Size(81, 13);
            this.lblDE_SNE_TipoNoExenta.TabIndex = 9;
            this.lblDE_SNE_TipoNoExenta.Text = "Tipo No Exenta";
            // 
            // gbDE_SujetaExenta
            // 
            this.gbDE_SujetaExenta.Controls.Add(this.lblDE_SE_NoExisteDetalleExenta);
            this.gbDE_SujetaExenta.Controls.Add(this.dgDE_SE_DetalleExenta);
            this.gbDE_SujetaExenta.Location = new System.Drawing.Point(20, 248);
            this.gbDE_SujetaExenta.Name = "gbDE_SujetaExenta";
            this.gbDE_SujetaExenta.Size = new System.Drawing.Size(789, 123);
            this.gbDE_SujetaExenta.TabIndex = 0;
            this.gbDE_SujetaExenta.TabStop = false;
            this.gbDE_SujetaExenta.Text = " Detalle Exenta ";
            // 
            // lblDE_SE_NoExisteDetalleExenta
            // 
            this.lblDE_SE_NoExisteDetalleExenta.AutoSize = true;
            this.lblDE_SE_NoExisteDetalleExenta.Location = new System.Drawing.Point(26, 24);
            this.lblDE_SE_NoExisteDetalleExenta.Name = "lblDE_SE_NoExisteDetalleExenta";
            this.lblDE_SE_NoExisteDetalleExenta.Size = new System.Drawing.Size(175, 13);
            this.lblDE_SE_NoExisteDetalleExenta.TabIndex = 19;
            this.lblDE_SE_NoExisteDetalleExenta.Text = "No hay informado detalle de Exenta";
            this.lblDE_SE_NoExisteDetalleExenta.Visible = false;
            // 
            // dgDE_SE_DetalleExenta
            // 
            this.dgDE_SE_DetalleExenta.AddUltimaFilaSiNoHayDisponile = false;
            this.dgDE_SE_DetalleExenta.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDE_SE_DetalleExenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgDE_SE_DetalleExenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDE_SE_DetalleExenta.ComboValores = null;
            this.dgDE_SE_DetalleExenta.ContextMenuStripGrid = null;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDE_SE_DetalleExenta.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgDE_SE_DetalleExenta.DSDatos = null;
            this.dgDE_SE_DetalleExenta.Location = new System.Drawing.Point(29, 19);
            this.dgDE_SE_DetalleExenta.Name = "dgDE_SE_DetalleExenta";
            this.dgDE_SE_DetalleExenta.NombreTabla = "";
            this.dgDE_SE_DetalleExenta.RowHeaderInitWidth = 41;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDE_SE_DetalleExenta.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgDE_SE_DetalleExenta.RowNumber = false;
            this.dgDE_SE_DetalleExenta.Size = new System.Drawing.Size(445, 97);
            this.dgDE_SE_DetalleExenta.TabIndex = 18;
            this.dgDE_SE_DetalleExenta.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgDE_SE_DetalleExenta_DataBindingComplete);
            // 
            // frmSiiConsultaViewFactInformadaProveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 682);
            this.Controls.Add(this.gbCabecera);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControlFactura);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmSiiConsultaViewFactInformadaProveedor";
            this.Text = "Consulta de Factura Informada por Proveedor (datos en Hacienda)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSiiConsultaViewFactInformadaProveedor_FormClosing);
            this.Load += new System.EventHandler(this.frmSiiConsultaViewFactInformadaProveedor_Load);
            this.Shown += new System.EventHandler(this.frmSiiConsultaViewFactInformadaProveedor_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmSiiConsultaViewFactInformadaProveedor_KeyDown);
            this.gbCabecera.ResumeLayout(false);
            this.gbCabecera.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControlFactura.ResumeLayout(false);
            this.tabPageDatosGrles.ResumeLayout(false);
            this.tabPageDatosGrles.PerformLayout();
            this.gbEntidadSucedida.ResumeLayout(false);
            this.gbEntidadSucedida.PerformLayout();
            this.gbDatosInmueble.ResumeLayout(false);
            this.gbDatosInmueble.PerformLayout();
            this.gbImporteRectificacion.ResumeLayout(false);
            this.gbImporteRectificacion.PerformLayout();
            this.gbFactRectificada.ResumeLayout(false);
            this.gbFactRectificada.PerformLayout();
            this.tabPageDesgloseFactura.ResumeLayout(false);
            this.gbDF_NoSujeta.ResumeLayout(false);
            this.gbDF_NoSujeta.PerformLayout();
            this.gbDF_Sujeta.ResumeLayout(false);
            this.gbDF_SujetaNoExenta.ResumeLayout(false);
            this.gbDF_SujetaNoExenta.PerformLayout();
            this.gbDF_SNE_DetalleIVA.ResumeLayout(false);
            this.gbDF_SNE_DetalleIVA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDF_SNE_DetalleIVA)).EndInit();
            this.gbDF_SujetaExenta.ResumeLayout(false);
            this.gbDF_SujetaExenta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDF_SE_DetalleExenta)).EndInit();
            this.tabPagePrestacionServicios.ResumeLayout(false);
            this.gbDPS_NoSujeta.ResumeLayout(false);
            this.gbDPS_NoSujeta.PerformLayout();
            this.gbDPS_Sujeta.ResumeLayout(false);
            this.gbDPS_SujetaNoExenta.ResumeLayout(false);
            this.gbDPS_SujetaNoExenta.PerformLayout();
            this.gbDPS_SNE_DetalleIVA.ResumeLayout(false);
            this.gbDPS_SNE_DetalleIVA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDPS_SNE_DetalleIVA)).EndInit();
            this.gbDPS_SujetaExenta.ResumeLayout(false);
            this.gbDPS_SujetaExenta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDPS_SE_DetalleExenta)).EndInit();
            this.tabPageEntrega.ResumeLayout(false);
            this.gbDE_NoSujeta.ResumeLayout(false);
            this.gbDE_NoSujeta.PerformLayout();
            this.gbDE_Sujeta.ResumeLayout(false);
            this.gbDE_SujetaNoExenta.ResumeLayout(false);
            this.gbDE_SujetaNoExenta.PerformLayout();
            this.gbDE_SNE_DetalleIVA.ResumeLayout(false);
            this.gbDE_SNE_DetalleIVA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDE_SNE_DetalleIVA)).EndInit();
            this.gbDE_SujetaExenta.ResumeLayout(false);
            this.gbDE_SujetaExenta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDE_SE_DetalleExenta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSalir;
        private System.Windows.Forms.TabControl tabControlFactura;
        private System.Windows.Forms.TabPage tabPageDatosGrles;
        private System.Windows.Forms.TabPage tabPageDesgloseFactura;
        private System.Windows.Forms.TabPage tabPagePrestacionServicios;
        private System.Windows.Forms.TabPage tabPageEntrega;
        private System.Windows.Forms.Label lblEjercicio;
        private System.Windows.Forms.TextBox txtEjercicio;
        private System.Windows.Forms.TextBox txtPeriodo;
        private System.Windows.Forms.Label lblPeriodo;
        private System.Windows.Forms.GroupBox gbCabecera;
        private System.Windows.Forms.TextBox txtFechaDoc;
        private System.Windows.Forms.Label lblFechaDoc;
        private System.Windows.Forms.TextBox txtNoFact;
        private System.Windows.Forms.Label lblFechaFactura;
        private System.Windows.Forms.TextBox txtProveedorNIF;
        private System.Windows.Forms.Label lblProveedorNIF;
        private System.Windows.Forms.GroupBox gbFactRectificada;
        private System.Windows.Forms.TextBox txtRectificadaFechaExpedicionFacturaEmisor;
        private System.Windows.Forms.Label lblRectificadaFechaExpedicionFacturaEmisor;
        private System.Windows.Forms.TextBox txtlRectificadaNumSeriFacturaEmisor;
        private System.Windows.Forms.Label lblRectificadaNumSeriFacturaEmisor;
        private System.Windows.Forms.TextBox txtTipoRectificativa;
        private System.Windows.Forms.Label lblTipoRectificativa;
        private System.Windows.Forms.TextBox txtTipoFactura;
        private System.Windows.Forms.Label lblTipoFactura;
        private System.Windows.Forms.TextBox txtNumSerieFacturaEmisorResumenFin;
        private System.Windows.Forms.Label lblNumSerieFacturaEmisorResumenFin;
        private System.Windows.Forms.TextBox txtFechaOperacion;
        private System.Windows.Forms.Label lblFechaOperacion;
        private System.Windows.Forms.GroupBox gbImporteRectificacion;
        private System.Windows.Forms.TextBox txtImpRecCuotaRecargoRectificado;
        private System.Windows.Forms.Label lblImpRecCuotaRecargoRectificado;
        private System.Windows.Forms.TextBox txtImpRecCuotaRectificada;
        private System.Windows.Forms.Label lblImpRecCuotaRectificada;
        private System.Windows.Forms.TextBox txtImpRecBaseRectificada;
        private System.Windows.Forms.Label lblImpRecBaseRectificada;
        private System.Windows.Forms.TextBox txtClaveRegimenEspecialOTrascendencia;
        private System.Windows.Forms.Label lblClaveRegimenEspecialOTrascendencia;
        private System.Windows.Forms.TextBox txtBaseImponibleACoste;
        private System.Windows.Forms.Label lblBaseImponibleACoste;
        private System.Windows.Forms.GroupBox gbDatosInmueble;
        private System.Windows.Forms.TextBox txtReferenciaCatastral;
        private System.Windows.Forms.Label lblReferenciaCatastral;
        private System.Windows.Forms.TextBox txtSituacionInmueble;
        private System.Windows.Forms.Label lblSituacionInmueble;
        private System.Windows.Forms.TextBox txtDescripcionOperacion;
        private System.Windows.Forms.Label lblDescripcionOperacion;
        private System.Windows.Forms.TextBox txtEmitidaPorTerceros;
        private System.Windows.Forms.Label lblEmitidaPorTerceros;
        private System.Windows.Forms.TextBox txtImporteTransmisionSujetoAIVA;
        private System.Windows.Forms.Label lblImporteTransmisionSujetoAIVA;
        private System.Windows.Forms.TextBox txtFechaHoraEstadoCuadre;
        private System.Windows.Forms.Label lblFechaHoraEstadoCuadre;
        private System.Windows.Forms.TextBox txtProveedorNombreRazonSocial;
        private System.Windows.Forms.Label lblProveedorNombreRazonSocial;
        private System.Windows.Forms.TextBox txtEstadoCuadre;
        private System.Windows.Forms.Label lblEstadoCudre;
        private System.Windows.Forms.TextBox txtImporteTotal;
        private System.Windows.Forms.Label lblImporteTotal;
        private System.Windows.Forms.GroupBox gbEntidadSucedida;
        private System.Windows.Forms.TextBox txtEntidadSucedidaNombreRazonSocial;
        private System.Windows.Forms.Label lblEntidadSucedidaNombreRazonSocial;
        private System.Windows.Forms.TextBox txtEntidadSucedidaNIF;
        private System.Windows.Forms.Label lblEntidadSucedidaNIF;
        private System.Windows.Forms.GroupBox gbDF_NoSujeta;
        private System.Windows.Forms.TextBox txtDF_NS_ImporteTAIReglasLocalizacion;
        private System.Windows.Forms.Label lblDF_NS_ImporteTAIReglasLocalizacion;
        private System.Windows.Forms.TextBox txtDF_NS_ImporteArticulos7_14_Otros;
        private System.Windows.Forms.Label lblDF_NS_ImporteArticulos7_14_Otros;
        private System.Windows.Forms.GroupBox gbDF_Sujeta;
        private System.Windows.Forms.GroupBox gbDF_SujetaNoExenta;
        private System.Windows.Forms.GroupBox gbDF_SNE_DetalleIVA;
        private ObjectModel.TGGrid dgDF_SNE_DetalleIVA;
        private System.Windows.Forms.TextBox txtDF_SNE_TipoNoExenta;
        private System.Windows.Forms.Label lblDF_SNE_TipoNoExenta;
        private System.Windows.Forms.GroupBox gbDF_SujetaExenta;
        private System.Windows.Forms.Label lblDF_SNE_NoExisteDetalleIVA;
        private System.Windows.Forms.GroupBox gbDPS_NoSujeta;
        private System.Windows.Forms.TextBox txtDPS_NS_ImporteTAIReglasLocalizacion;
        private System.Windows.Forms.Label lblDPS_NS_ImporteTAIReglasLocalizacion;
        private System.Windows.Forms.TextBox txtDPS_NS_ImporteArticulos7_14_Otros;
        private System.Windows.Forms.Label lblDPS_NS_ImporteArticulos7_14_Otros;
        private System.Windows.Forms.GroupBox gbDPS_Sujeta;
        private System.Windows.Forms.GroupBox gbDPS_SujetaNoExenta;
        private System.Windows.Forms.GroupBox gbDPS_SNE_DetalleIVA;
        private System.Windows.Forms.Label lblDPS_SNE_NoExisteDetalleIVA;
        private ObjectModel.TGGrid dgDPS_SNE_DetalleIVA;
        private System.Windows.Forms.TextBox txtDPS_SNE_TipoNoExenta;
        private System.Windows.Forms.Label lblDPS_SNE_TipoNoExenta;
        private System.Windows.Forms.GroupBox gbDPS_SujetaExenta;
        private System.Windows.Forms.GroupBox gbDE_NoSujeta;
        private System.Windows.Forms.TextBox txtDE_NS_ImporteTAIReglasLocalizacion;
        private System.Windows.Forms.Label lblDE_NS_ImporteTAIReglasLocalizacion;
        private System.Windows.Forms.TextBox txtDE_NS_ImporteArticulos7_14_Otros;
        private System.Windows.Forms.Label lblDE_NS_ImporteArticulos7_14_Otros;
        private System.Windows.Forms.GroupBox gbDE_Sujeta;
        private System.Windows.Forms.GroupBox gbDE_SujetaNoExenta;
        private System.Windows.Forms.GroupBox gbDE_SNE_DetalleIVA;
        private System.Windows.Forms.Label lblDE_SNE_NoExisteDetalleIVA;
        private ObjectModel.TGGrid dgDE_SNE_DetalleIVA;
        private System.Windows.Forms.TextBox txtDE_SNE_TipoNoExenta;
        private System.Windows.Forms.Label lblDE_SNE_TipoNoExenta;
        private System.Windows.Forms.GroupBox gbDE_SujetaExenta;
        private System.Windows.Forms.TextBox txtCobros;
        private System.Windows.Forms.Label lblCobros;
        private System.Windows.Forms.TextBox txtCupon;
        private System.Windows.Forms.Label lblCupon;
        private System.Windows.Forms.TextBox txtVariosDestinatarios;
        private System.Windows.Forms.Label lblVariosDestinatarios;
        private System.Windows.Forms.TextBox txtNumRegistroAcuerdoFacturacion;
        private System.Windows.Forms.Label lblNumRegistroAcuerdoFacturacion;
        private System.Windows.Forms.TextBox txtClaveRegimenEspecialOTrasAdicional2;
        private System.Windows.Forms.Label lblClaveRegimenEspecialOTrasAdicional2;
        private System.Windows.Forms.TextBox txtClaveRegimenEspecialOTrasAdicional1;
        private System.Windows.Forms.Label lblClaveRegimenEspecialOTrasAdicional1;
        private System.Windows.Forms.TextBox txtFactSimplificadaArticulos72_73;
        private System.Windows.Forms.Label lblFactSimplificadaArticulos72_73;
        private System.Windows.Forms.TextBox txtRefExterna;
        private System.Windows.Forms.Label lblRefExterna;
        private System.Windows.Forms.TextBox txtRegistroPrevioGGEEoREDEMEoCompetencia;
        private System.Windows.Forms.Label lblRegistroPrevioGGEEoREDEMEoCompetencia;
        private System.Windows.Forms.TextBox txtMacrodato;
        private System.Windows.Forms.Label lblMacrodato;
        private System.Windows.Forms.TextBox txtFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas;
        private System.Windows.Forms.Label lblFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas;
        private System.Windows.Forms.TextBox txtFacturaSinIdentifDestinatarioArticulo61d;
        private System.Windows.Forms.Label lblFacturaSinIdentifDestinatarioArticulo61d;
        private System.Windows.Forms.TextBox txtEmisorFacturaNIF;
        private System.Windows.Forms.Label lblEmisorFacturaNIF;
        private System.Windows.Forms.TextBox txtNombreRazonSocialEmisorFact;
        private System.Windows.Forms.Label lblNombreRazonSocialEmisorFact;
        private System.Windows.Forms.Label lblDF_SE_NoExisteDetalleExenta;
        private ObjectModel.TGGrid dgDF_SE_DetalleExenta;
        private System.Windows.Forms.Label lblDPS_SE_NoExisteDetalleExenta;
        private ObjectModel.TGGrid dgDPS_SE_DetalleExenta;
        private System.Windows.Forms.Label lblDE_SE_NoExisteDetalleExenta;
        private ObjectModel.TGGrid dgDE_SE_DetalleExenta;
    }
}